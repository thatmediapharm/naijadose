"use client";

import React, { useState, useMemo } from "react";
import { checkWeightPlausibility, estimateWeightFromAge } from "@/lib/whoGrowth";
import { Scale, ArrowRight, ShieldAlert, Sparkles, Info } from "lucide-react";

interface WeightEstimatorProps {
  onUseWeight: (weightKg: number, ageMonths: number) => void;
}

export default function WeightEstimator({ onUseWeight }: WeightEstimatorProps) {
  const [ageYears, setAgeYears] = useState(2);
  const [ageMonths, setAgeMonths] = useState(0);

  const totalAgeMonths = ageYears * 12 + ageMonths;

  const estimate = useMemo(() => {
    return estimateWeightFromAge(totalAgeMonths);
  }, [totalAgeMonths]);

  const plausibility = useMemo(() => {
    return checkWeightPlausibility(totalAgeMonths, estimate.estimatedKg);
  }, [totalAgeMonths, estimate.estimatedKg]);

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Disclaimer Box */}
      <div className="bg-amber-950/40 border border-amber-600/50 rounded-2xl p-4 text-xs text-amber-200 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <h3 className="font-bold text-amber-300">CLINICAL NOTICE: SCALE IS GOLD STANDARD</h3>
          <p className="mt-0.5 leading-relaxed">
            Measuring the child on a calibrated paediatric scale is always the safest method.
            Use this emergency APLS formula only when a scale is unavailable in primary care or outreach clinics.
          </p>
        </div>
      </div>

      {/* Main Estimator Card */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex items-center gap-2">
          <Scale className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base font-bold text-white">
            Emergency Weight Estimator (APLS / WHO Standard)
          </h2>
        </div>

        {/* Age inputs */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Age in Years (0–12)
            </label>
            <div className="flex items-center bg-slate-900 border border-slate-700 rounded-xl overflow-hidden">
              <button
                type="button"
                onClick={() => setAgeYears(Math.max(0, ageYears - 1))}
                className="px-4 py-2.5 text-slate-300 hover:bg-slate-800 font-bold"
              >
                -
              </button>
              <input
                type="number"
                min="0"
                max="12"
                value={ageYears}
                onChange={(e) => setAgeYears(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-transparent text-center font-bold text-white text-base focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setAgeYears(Math.min(12, ageYears + 1))}
                className="px-4 py-2.5 text-slate-300 hover:bg-slate-800 font-bold"
              >
                +
              </button>
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Additional Months (0–11)
            </label>
            <div className="flex items-center bg-slate-900 border border-slate-700 rounded-xl overflow-hidden">
              <button
                type="button"
                onClick={() => setAgeMonths(Math.max(0, ageMonths - 1))}
                className="px-4 py-2.5 text-slate-300 hover:bg-slate-800 font-bold"
              >
                -
              </button>
              <input
                type="number"
                min="0"
                max="11"
                value={ageMonths}
                onChange={(e) =>
                  setAgeMonths(Math.min(11, Math.max(0, parseInt(e.target.value) || 0)))
                }
                className="w-full bg-transparent text-center font-bold text-white text-base focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setAgeMonths(Math.min(11, ageMonths + 1))}
                className="px-4 py-2.5 text-slate-300 hover:bg-slate-800 font-bold"
              >
                +
              </button>
            </div>
          </div>
        </div>

        {/* Estimated Output Result */}
        <div className="bg-slate-950/80 rounded-2xl p-6 border border-slate-700/80 text-center space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Estimated Paediatric Weight
          </span>
          <div>
            <span className="text-5xl font-black text-emerald-400">
              {estimate.estimatedKg}
            </span>
            <span className="text-slate-400 font-bold text-xl ml-1.5">kg</span>
          </div>

          <p className="text-xs font-mono text-emerald-300/90">
            {estimate.formulaDescription}
          </p>

          <div className="pt-3 flex flex-wrap justify-center gap-4 text-xs text-slate-400 border-t border-slate-800">
            <span>
              WHO Median: <strong>{plausibility.medianKg} kg</strong>
            </span>
            <span>•</span>
            <span>
              Typical Range:{" "}
              <strong>
                {plausibility.expectedMinKg} – {plausibility.expectedMaxKg} kg
              </strong>
            </span>
          </div>
        </div>

        {/* Button to transfer to calculator */}
        <button
          onClick={() => onUseWeight(estimate.estimatedKg, totalAgeMonths)}
          className="w-full py-3.5 rounded-xl font-bold text-sm text-slate-950 bg-emerald-400 hover:bg-emerald-300 transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50"
        >
          <span>Use {estimate.estimatedKg} kg in Dose Calculator</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
