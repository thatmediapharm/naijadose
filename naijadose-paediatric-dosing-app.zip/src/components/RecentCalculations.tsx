"use client";

import React from "react";
import { StoredCalculation, Drug } from "@/lib/types";
import {
  Clock,
  RotateCcw,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  ArrowRight,
  User,
} from "lucide-react";

interface RecentCalculationsProps {
  recent: StoredCalculation[];
  onReload: (calc: StoredCalculation) => void;
  onClear: () => void;
  drugs: Drug[];
}

export default function RecentCalculations({
  recent,
  onReload,
  onClear,
  drugs,
}: RecentCalculationsProps) {
  const formatTimeAgo = (isoString: string) => {
    try {
      const now = new Date().getTime();
      const past = new Date(isoString).getTime();
      const diffSecs = Math.floor((now - past) / 1000);
      if (diffSecs < 60) return "Just now";
      const diffMins = Math.floor(diffSecs / 60);
      if (diffMins < 60) return `${diffMins}m ago`;
      const diffHours = Math.floor(diffMins / 60);
      if (diffHours < 24) return `${diffHours}h ago`;
      return `${Math.floor(diffHours / 24)}d ago`;
    } catch {
      return "Recently";
    }
  };

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-emerald-400" />
          <div>
            <h2 className="text-base font-bold text-white">Recent Calculations</h2>
            <p className="text-xs text-slate-400">
              Quickly repeat or review recent dispensing sessions
            </p>
          </div>
        </div>

        {recent.length > 0 && (
          <button
            onClick={onClear}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-rose-300 hover:text-rose-200 bg-rose-950/40 hover:bg-rose-950/70 border border-rose-800/50 transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear</span>
          </button>
        )}
      </div>

      {/* List */}
      {recent.length > 0 ? (
        <div className="space-y-2.5">
          {recent.map((item) => {
            const ageMonths = item.patientAgeMonths;
            const ageDisplay =
              ageMonths < 12
                ? `${ageMonths}m`
                : `${(ageMonths / 12).toFixed(1).replace(".0", "")}y`;

            const primaryDose =
              item.calculatedVolumeMl !== null
                ? `${item.calculatedVolumeMl} mL`
                : item.calculatedTablets !== null
                ? `${item.calculatedTablets} Tab`
                : item.calculatedDoseMg !== null
                ? `${item.calculatedDoseMg} mg`
                : "Blocked";

            return (
              <div
                key={item.id}
                className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/70 rounded-xl p-3.5 shadow-sm transition flex items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="p-2 rounded-xl bg-slate-900 border border-slate-700/80 shrink-0 mt-0.5">
                    {item.safetyStatus === "hard_stop" ? (
                      <AlertOctagon className="w-5 h-5 text-rose-400" />
                    ) : item.safetyStatus === "warning" ? (
                      <AlertTriangle className="w-5 h-5 text-amber-400" />
                    ) : (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm text-white truncate">
                        {item.drugName}
                      </h4>
                      <span className="text-[11px] font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30 shrink-0">
                        {primaryDose}
                      </span>
                    </div>

                    <p className="text-xs text-slate-400 truncate">
                      {item.formulationLabel}
                    </p>

                    <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                      <span>
                        Pt: <strong>{item.patientWeightKg} kg</strong> ({ageDisplay})
                      </span>
                      <span>•</span>
                      <span>{item.frequencyText}</span>
                      <span>•</span>
                      <span className="text-slate-500">{formatTimeAgo(item.createdAt)}</span>
                    </div>
                  </div>
                </div>

                {/* Repeat Button */}
                <button
                  onClick={() => onReload(item)}
                  className="px-3 py-2 rounded-lg bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 text-xs font-bold transition flex items-center gap-1.5 shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Reload</span>
                </button>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-8 text-center bg-slate-800/40 border border-slate-700/60 rounded-2xl">
          <Clock className="w-8 h-8 text-slate-500 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-300">
            No calculations in this session yet.
          </p>
          <p className="text-xs text-slate-400 mt-1">
            Calculations you perform will appear here for fast 1-tap re-use.
          </p>
        </div>
      )}
    </div>
  );
}
