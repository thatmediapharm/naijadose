/**
 * WHO Child Growth Standards (Median & Approximate 3rd - 97th percentiles)
 * and APLS emergency weight estimation formulas.
 */

export interface WhoPlausibilityResult {
  isPlausible: boolean;
  isExtreme: boolean;
  expectedMinKg: number;
  expectedMaxKg: number;
  medianKg: number;
  message?: string;
}

// Median weight by age in months (composite WHO 50th percentile)
const WHO_MEDIAN_TABLE: Record<number, { min: number; median: number; max: number }> = {
  0: { min: 2.5, median: 3.3, max: 4.4 },
  1: { min: 3.2, median: 4.2, max: 5.5 },
  2: { min: 4.0, median: 5.1, max: 6.6 },
  3: { min: 4.5, median: 5.8, max: 7.5 },
  4: { min: 5.0, median: 6.4, max: 8.2 },
  5: { min: 5.4, median: 6.9, max: 8.8 },
  6: { min: 5.8, median: 7.3, max: 9.3 },
  7: { min: 6.1, median: 7.7, max: 9.8 },
  8: { min: 6.3, median: 8.0, max: 10.2 },
  9: { min: 6.6, median: 8.3, max: 10.6 },
  10: { min: 6.8, median: 8.6, max: 11.0 },
  11: { min: 7.0, median: 8.8, max: 11.3 },
  12: { min: 7.1, median: 9.2, max: 11.8 }, // 1 yr
  18: { min: 8.2, median: 10.6, max: 13.5 },
  24: { min: 9.2, median: 12.0, max: 15.3 }, // 2 yr
  36: { min: 11.0, median: 14.2, max: 18.2 }, // 3 yr
  48: { min: 12.5, median: 16.3, max: 21.2 }, // 4 yr
  60: { min: 14.0, median: 18.3, max: 24.5 }, // 5 yr
  72: { min: 15.5, median: 20.5, max: 28.0 }, // 6 yr
  84: { min: 17.5, median: 23.0, max: 32.5 }, // 7 yr
  96: { min: 19.5, median: 25.5, max: 37.0 }, // 8 yr
  108: { min: 21.5, median: 28.5, max: 42.0 }, // 9 yr
  120: { min: 24.0, median: 32.0, max: 48.0 }, // 10 yr
  132: { min: 26.5, median: 36.0, max: 55.0 }, // 11 yr
  144: { min: 30.0, median: 40.5, max: 62.0 }, // 12 yr
  168: { min: 38.0, median: 50.0, max: 75.0 }, // 14 yr
};

/**
 * Checks if the entered weight is plausible for the patient's age.
 */
export function checkWeightPlausibility(
  ageMonths: number,
  weightKg: number
): WhoPlausibilityResult {
  if (weightKg <= 0 || isNaN(weightKg)) {
    return {
      isPlausible: false,
      isExtreme: true,
      expectedMinKg: 0.5,
      expectedMaxKg: 150,
      medianKg: 10,
      message: "Weight must be greater than 0 kg.",
    };
  }

  // Find nearest anchors
  const monthKeys = Object.keys(WHO_MEDIAN_TABLE)
    .map(Number)
    .sort((a, b) => a - b);

  let lowerKey = monthKeys[0];
  let upperKey = monthKeys[monthKeys.length - 1];

  for (let i = 0; i < monthKeys.length; i++) {
    if (monthKeys[i] <= ageMonths) {
      lowerKey = monthKeys[i];
    }
    if (monthKeys[i] >= ageMonths && upperKey === monthKeys[monthKeys.length - 1]) {
      upperKey = monthKeys[i];
      break;
    }
  }

  let expectedMin: number;
  let expectedMax: number;
  let median: number;

  if (lowerKey === upperKey) {
    expectedMin = WHO_MEDIAN_TABLE[lowerKey].min;
    expectedMax = WHO_MEDIAN_TABLE[lowerKey].max;
    median = WHO_MEDIAN_TABLE[lowerKey].median;
  } else {
    const fraction = (ageMonths - lowerKey) / (upperKey - lowerKey);
    const low = WHO_MEDIAN_TABLE[lowerKey];
    const high = WHO_MEDIAN_TABLE[upperKey];
    expectedMin = low.min + fraction * (high.min - low.min);
    expectedMax = low.max + fraction * (high.max - low.max);
    median = low.median + fraction * (high.median - low.median);
  }

  // Wide buffer for Nigerian / clinical variation: 0.55x lower bound to 1.75x upper bound
  const plausibleLow = Math.max(0.8, Number((expectedMin * 0.65).toFixed(1)));
  const plausibleHigh = Number((expectedMax * 1.5).toFixed(1));

  // Extreme cutoff (potential typing error like 40kg instead of 4.0kg or 12yo weight entered for infant)
  const isExtreme = weightKg < plausibleLow * 0.7 || weightKg > plausibleHigh * 1.35;
  const isPlausible = weightKg >= plausibleLow && weightKg <= plausibleHigh;

  const ageLabel =
    ageMonths < 12
      ? `${Math.round(ageMonths)} month-old`
      : `${(ageMonths / 12).toFixed(1).replace(".0", "")} year-old`;

  let message: string | undefined;
  if (!isPlausible) {
    if (weightKg > plausibleHigh) {
      message = `Entered weight of ${weightKg} kg appears very high for a ${ageLabel} (WHO expected median ~${median.toFixed(
        1
      )} kg, typical range ${expectedMin.toFixed(1)}–${expectedMax.toFixed(
        1
      )} kg). Please verify before dispensing.`;
    } else {
      message = `Entered weight of ${weightKg} kg appears low for a ${ageLabel} (WHO expected median ~${median.toFixed(
        1
      )} kg, typical range ${expectedMin.toFixed(1)}–${expectedMax.toFixed(
        1
      )} kg). Check for severe acute malnutrition or scale unit error.`;
    }
  }

  return {
    isPlausible,
    isExtreme,
    expectedMinKg: Number(expectedMin.toFixed(1)),
    expectedMaxKg: Number(expectedMax.toFixed(1)),
    medianKg: Number(median.toFixed(1)),
    message,
  };
}

/**
 * Emergency Weight Estimator (APLS / WHO guideline)
 * Useful when a working weighing scale is unavailable in rural clinics.
 */
export function estimateWeightFromAge(ageMonths: number): {
  estimatedKg: number;
  formulaDescription: string;
} {
  const ageYears = ageMonths / 12;

  if (ageMonths < 12) {
    // 0 to 12 months: (months + 9) / 2
    const est = (ageMonths + 9) / 2;
    return {
      estimatedKg: Number(Math.max(2.5, est).toFixed(1)),
      formulaDescription: "APLS formula: (Age in months + 9) / 2",
    };
  } else if (ageYears <= 5) {
    // 1 to 5 years: (2 * years) + 8
    const est = 2 * ageYears + 8;
    return {
      estimatedKg: Number(est.toFixed(1)),
      formulaDescription: "APLS formula: (2 × Age in years) + 8",
    };
  } else {
    // 6 to 12 years: (3 * years) + 7
    const est = 3 * ageYears + 7;
    return {
      estimatedKg: Number(est.toFixed(1)),
      formulaDescription: "APLS formula: (3 × Age in years) + 7",
    };
  }
}
