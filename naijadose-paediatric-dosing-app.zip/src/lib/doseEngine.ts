import {
  CalculationInput,
  CalculationResult,
  SafetyAlert,
  DrugFormulation,
  WeightBandRule,
  AgeBandRule,
} from "./types";
import { checkWeightPlausibility } from "./whoGrowth";

/**
 * Rounds a liquid volume (mL) down to safe, practical increments.
 * Oral syringes typically have 0.5 mL graduations.
 * In drops formulations (perVolumeMl <= 1), we round to nearest 0.1 mL.
 * Rule from PRD: "round volumes down to practical measurable values (0.5 mL for oral syringes,
 * half-tablets only where scored). Never round a dose up past the maximum."
 */
export function roundVolumeSafely(volumeMl: number, isDrops = false): number {
  if (volumeMl <= 0) return 0;
  if (isDrops) {
    // 0.1 mL steps
    return Math.floor(volumeMl * 10) / 10;
  }
  // 0.5 mL steps rounded down
  return Math.floor(volumeMl * 2) / 2;
}

/**
 * Rounds tablet count safely according to whether tablet is scored.
 */
export function roundTabletsSafely(tablets: number, isScored: boolean): number {
  if (tablets <= 0) return 0;
  if (isScored) {
    // Allow half tablets (0.5 increments), round down to nearest 0.5
    return Math.floor(tablets * 2) / 2;
  }
  // Unscored: round down to whole tablet
  return Math.floor(tablets);
}

/**
 * Core clinical calculation engine for NaijaDose.
 * Pure TypeScript, zero external network dependency, 100% offline-ready.
 */
export function calculateDose(input: CalculationInput): CalculationResult {
  const {
    drug,
    weightKg,
    ageYears,
    ageMonths,
    selectedFormulation,
    doseSelectedMgPerKg,
  } = input;

  const totalAgeMonths = (ageYears || 0) * 12 + (ageMonths || 0);

  const hardStops: SafetyAlert[] = [];
  const softWarnings: SafetyAlert[] = [];

  // ==========================================
  // 1. HARD STOP VALIDATIONS
  // ==========================================

  // Check 1: Weight bounds
  if (weightKg === undefined || weightKg === null || isNaN(weightKg) || weightKg <= 0) {
    hardStops.push({
      type: "hard_stop",
      code: "INVALID_WEIGHT",
      title: "Weight Required",
      message: "Please enter a valid patient weight greater than 0 kg.",
      actionRequired: "Input patient's measured weight.",
    });
  } else if (weightKg < 0.5 || weightKg > 150) {
    hardStops.push({
      type: "hard_stop",
      code: "WEIGHT_OUT_OF_BOUNDS",
      title: "Weight Out of Safe Paediatric Range",
      message: `Entered weight (${weightKg} kg) is outside allowable range (0.5 kg – 150 kg).`,
      actionRequired: "Verify patient's scale reading and unit (kg).",
    });
  }

  // Check 2: Age minimum
  if (drug.minAgeMonths > 0 && totalAgeMonths < drug.minAgeMonths) {
    const minAgeDisplay =
      drug.minAgeMonths < 12
        ? `${drug.minAgeMonths} month${drug.minAgeMonths > 1 ? "s" : ""}`
        : `${(drug.minAgeMonths / 12).toFixed(1).replace(".0", "")} year${
            drug.minAgeMonths / 12 > 1 ? "s" : ""
          }`;
    hardStops.push({
      type: "hard_stop",
      code: "MIN_AGE_RESTRICTION",
      title: "Age Below Safe Minimum",
      message: `${drug.genericName} is not recommended for children under ${minAgeDisplay}. Current age is ${totalAgeMonths.toFixed(
        1
      )} months.`,
      actionRequired: "Do not dispense. Refer to a paediatrician or choose an age-appropriate alternative.",
    });
  }

  // Check 3: Minimum weight for specific drug (e.g. Coartem < 5 kg)
  if (drug.minWeightKg && weightKg < drug.minWeightKg) {
    hardStops.push({
      type: "hard_stop",
      code: "MIN_WEIGHT_RESTRICTION",
      title: "Weight Below Safe Minimum",
      message: `${drug.genericName} is not recommended for patients weighing under ${drug.minWeightKg} kg. Current weight is ${weightKg} kg.`,
      actionRequired: "Do not dispense. Refer to a doctor or hospital for specialist alternative protocol (e.g. parenteral artesunate).",
    });
  }

  // ==========================================
  // 2. SOFT WARNING VALIDATIONS
  // ==========================================

  // Warning 1: Neonate flag (<1 month / 30 days)
  if (totalAgeMonths < 1 && weightKg > 0) {
    softWarnings.push({
      type: "soft_warning",
      code: "NEONATE_PATIENT",
      title: "Neonate Dosing Alert (< 1 Month)",
      message: "Neonates have immature hepatic and renal clearance. Paediatric specialist protocol is required.",
      actionRequired: "Consult a paediatrician before dispensing any systemic medication.",
    });
  }

  // Warning 2: Weight plausibility vs WHO Growth Standards
  if (weightKg > 0) {
    const plausibility = checkWeightPlausibility(totalAgeMonths, weightKg);
    if (!plausibility.isPlausible && plausibility.message) {
      softWarnings.push({
        type: "soft_warning",
        code: "WEIGHT_IMPLAUSIBLE",
        title: "Weight Plausibility Warning",
        message: plausibility.message,
        actionRequired: "Confirm scale calibration or verify patient's entered age.",
      });
    }
  }

  // Warning 3: Drug-specific clinical alerts
  if (drug.warnings) {
    // Add specific advisory note
    softWarnings.push({
      type: "info",
      code: "CLINICAL_ADVISORY",
      title: "Clinical Practice Note",
      message: drug.warnings,
    });
  }

  // Pick or fallback formulation
  const formulation: DrugFormulation | null =
    selectedFormulation ||
    (drug.formulations && drug.formulations.length > 0 ? drug.formulations[0] : null);

  // If hard-stops occurred at this initial input stage, return immediately
  if (hardStops.length > 0) {
    return {
      isSafe: false,
      hardStops,
      softWarnings,
      singleDoseMg: null,
      dailyDoseMg: null,
      dosesPerDay: drug.dosesPerDayMin || 1,
      frequencyText: drug.frequencyText,
      typicalDurationDays: drug.typicalDurationDays || 3,
      formulation,
      volumePerDoseMl: null,
      roundedVolumePerDoseMl: null,
      tabletsPerDose: null,
      roundedTabletsPerDose: null,
      displayDosePrimary: "Calculation Blocked",
      displayDoseSecondary: "Review safety hard-stop alerts above",
      formulaApplied: "Calculation stopped due to patient safety criteria.",
      isCappedAtMaxSingle: false,
      isCappedAtMaxDaily: false,
      counsellingNotes: drug.counsellingNotes,
      clinicalWarnings: drug.warnings,
      sourceReference: drug.sourceReference,
      disclaimer:
        "For professional use only. Supports, and never replaces, clinical judgment.",
    };
  }

  // ==========================================
  // 3. CALCULATION LOGIC BY METHOD
  // ==========================================

  let calculatedSingleDoseMg: number | null = null;
  let calculatedDailyDoseMg: number | null = null;
  let formulaApplied = "";
  let dosesPerDay = drug.dosesPerDayMin || 1;
  let frequencyText = drug.frequencyText;
  let typicalDurationDays = drug.typicalDurationDays || 3;
  let directTablets: number | null = null;
  let directVolumeMl: number | null = null;
  let isCappedAtMaxSingle = false;
  let isCappedAtMaxDaily = false;

  switch (drug.calcMethod) {
    case "mg_per_kg": {
      // Determine mg/kg factor
      const minMgKg = drug.doseMinMgPerKg || 10;
      const maxMgKg = drug.doseMaxMgPerKg || minMgKg;
      // Default to upper safe standard or user selected
      const chosenMgKg =
        doseSelectedMgPerKg && doseSelectedMgPerKg >= minMgKg && doseSelectedMgPerKg <= maxMgKg
          ? doseSelectedMgPerKg
          : maxMgKg;

      if (drug.doseBasis === "per_dose") {
        const rawSingle = chosenMgKg * weightKg;
        calculatedSingleDoseMg = rawSingle;
        dosesPerDay = drug.dosesPerDayMin || (drug.frequencyText.includes("q4") ? 4 : 3);
        calculatedDailyDoseMg = rawSingle * dosesPerDay;
        formulaApplied = `${chosenMgKg} mg/kg × ${weightKg} kg = ${rawSingle.toFixed(
          1
        )} mg per dose (${dosesPerDay} doses/day = ${(rawSingle * dosesPerDay).toFixed(1)} mg/day)`;
      } else {
        // per_day basis (e.g. Amoxicillin 40 mg/kg/day divided q8h or Zinc / Ferrous)
        const rawDaily = chosenMgKg * weightKg;
        calculatedDailyDoseMg = rawDaily;
        dosesPerDay = drug.dosesPerDayMin || 3;
        calculatedSingleDoseMg = rawDaily / dosesPerDay;
        formulaApplied = `${chosenMgKg} mg/kg/day × ${weightKg} kg = ${rawDaily.toFixed(
          1
        )} mg/day ÷ ${dosesPerDay} doses = ${calculatedSingleDoseMg.toFixed(1)} mg per dose`;
      }
      break;
    }

    case "weight_band": {
      // e.g. Coartem (Artemether-Lumefantrine)
      const bands = drug.bandRules?.weightBands || [];
      const matchedBand = bands.find(
        (b) => weightKg >= b.minKg && (b.maxKg === undefined || weightKg < b.maxKg)
      );

      if (!matchedBand) {
        hardStops.push({
          type: "hard_stop",
          code: "NO_WEIGHT_BAND_MATCH",
          title: "No Matching Weight Band",
          message: `Weight ${weightKg} kg does not match approved protocol bands for ${drug.genericName}.`,
          actionRequired: "Consult clinical reference for specialised dosing.",
        });
      } else {
        if (matchedBand.tablets !== undefined) {
          directTablets = matchedBand.tablets;
          formulaApplied = `Weight Band [${matchedBand.minKg} to <${matchedBand.maxKg || "+"} kg]: ${
            matchedBand.tablets
          } tablet${matchedBand.tablets > 1 ? "s" : ""} per dose`;
          if (matchedBand.instructions) {
            formulaApplied += ` (${matchedBand.instructions})`;
          }
        }
        if (matchedBand.doseMg !== undefined) {
          calculatedSingleDoseMg = matchedBand.doseMg;
        }
      }
      break;
    }

    case "age_band": {
      // e.g. Zinc, Albendazole, Cetirizine, Chlorpheniramine
      const bands = drug.bandRules?.ageBands || [];
      const matchedBand = bands.find(
        (b) => totalAgeMonths >= b.minMonths && (b.maxMonths === undefined || totalAgeMonths < b.maxMonths)
      );

      if (!matchedBand) {
        hardStops.push({
          type: "hard_stop",
          code: "NO_AGE_BAND_MATCH",
          title: "No Matching Age Band",
          message: `Age (${totalAgeMonths} months) does not fall into standard dosing bands for ${drug.genericName}.`,
          actionRequired: "Verify patient age or consult a paediatric specialist.",
        });
      } else {
        if (matchedBand.doseMg !== undefined) {
          calculatedSingleDoseMg = matchedBand.doseMg;
          calculatedDailyDoseMg = matchedBand.maxDailyMg || matchedBand.doseMg;
          formulaApplied = `Age Band [${matchedBand.minMonths} to <${
            matchedBand.maxMonths || "+"
          } months]: ${matchedBand.doseMg} mg`;
          if (matchedBand.frequencyText) {
            frequencyText = matchedBand.frequencyText;
          }
        }
        if (matchedBand.tablets !== undefined) {
          directTablets = matchedBand.tablets;
        }
      }
      break;
    }

    case "volume_per_kg": {
      // e.g. ORS Plan B (75 mL/kg over 4 hours)
      const mlPerKg = drug.doseMinMgPerKg || 75; // Using the numeric field as volume mL/kg
      const totalVolume = mlPerKg * weightKg;
      directVolumeMl = totalVolume;
      formulaApplied = `WHO Diarrhoea Rehydration (Plan B): ${mlPerKg} mL/kg × ${weightKg} kg = ${totalVolume.toFixed(
        0
      )} mL over 4 hours`;
      break;
    }

    case "fixed": {
      calculatedSingleDoseMg = drug.maxSingleDoseMg || 0;
      formulaApplied = `Fixed paediatric dose: ${calculatedSingleDoseMg} mg`;
      break;
    }
  }

  // ==========================================
  // 4. SAFETY CAPS (MAX SINGLE & MAX DAILY)
  // ==========================================

  if (calculatedSingleDoseMg !== null) {
    if (drug.maxSingleDoseMg && calculatedSingleDoseMg > drug.maxSingleDoseMg) {
      isCappedAtMaxSingle = true;
      softWarnings.push({
        type: "hard_stop", // Hard-stop alert cap as required in PRD #3
        code: "MAX_SINGLE_DOSE_EXCEEDED",
        title: "Dose Exceeds Maximum Single Dose Cap",
        message: `Calculated single dose (${calculatedSingleDoseMg.toFixed(
          1
        )} mg) exceeded maximum allowed single dose (${drug.maxSingleDoseMg} mg). Capped at ${
          drug.maxSingleDoseMg
        } mg.`,
        actionRequired: `Strictly capped to maximum safe ceiling of ${drug.maxSingleDoseMg} mg per dose.`,
      });
      calculatedSingleDoseMg = drug.maxSingleDoseMg;
    }

    // Check max mg/kg/day cap
    if (drug.maxDailyMgPerKg && weightKg > 0) {
      const maxAllowedDailyFromKg = drug.maxDailyMgPerKg * weightKg;
      if (calculatedDailyDoseMg && calculatedDailyDoseMg > maxAllowedDailyFromKg) {
        isCappedAtMaxDaily = true;
        softWarnings.push({
          type: "hard_stop",
          code: "MAX_DAILY_MG_PER_KG_EXCEEDED",
          title: "Daily Dose Exceeds mg/kg/day Ceiling",
          message: `Calculated daily total (${calculatedDailyDoseMg.toFixed(
            1
          )} mg) exceeded max daily limit of ${drug.maxDailyMgPerKg} mg/kg/day (${maxAllowedDailyFromKg.toFixed(
            1
          )} mg/day). Capped.`,
          actionRequired: `Dose capped to ${maxAllowedDailyFromKg.toFixed(1)} mg/day.`,
        });
        calculatedDailyDoseMg = maxAllowedDailyFromKg;
        calculatedSingleDoseMg = calculatedDailyDoseMg / dosesPerDay;
      }
    }

    // Check absolute max daily mg
    if (drug.maxDailyDoseMg && calculatedDailyDoseMg && calculatedDailyDoseMg > drug.maxDailyDoseMg) {
      isCappedAtMaxDaily = true;
      softWarnings.push({
        type: "hard_stop",
        code: "MAX_DAILY_DOSE_EXCEEDED",
        title: "Daily Dose Exceeds Absolute Maximum Cap",
        message: `Calculated daily dose (${calculatedDailyDoseMg.toFixed(
          1
        )} mg) exceeded absolute daily maximum (${drug.maxDailyDoseMg} mg). Capped at ${
          drug.maxDailyDoseMg
        } mg/day.`,
        actionRequired: `Strictly capped to maximum daily limit of ${drug.maxDailyDoseMg} mg/day.`,
      });
      calculatedDailyDoseMg = drug.maxDailyDoseMg;
      calculatedSingleDoseMg = calculatedDailyDoseMg / dosesPerDay;
    }
  }

  // ==========================================
  // 5. PHYSICAL FORMULATION CONVERSION
  // ==========================================

  let volumePerDoseMl: number | null = null;
  let roundedVolumePerDoseMl: number | null = null;
  let tabletsPerDose: number | null = null;
  let roundedTabletsPerDose: number | null = null;

  if (directVolumeMl !== null) {
    volumePerDoseMl = directVolumeMl;
    roundedVolumePerDoseMl = Math.round(directVolumeMl / 5) * 5; // e.g. Round to nearest 5 mL for large ORS volume
  } else if (directTablets !== null) {
    tabletsPerDose = directTablets;
    roundedTabletsPerDose = directTablets;
  } else if (calculatedSingleDoseMg !== null && formulation) {
    if (
      formulation.form === "syrup" ||
      formulation.form === "suspension" ||
      formulation.form === "drops"
    ) {
      if (formulation.perVolumeMl && formulation.strengthMg > 0) {
        const rawVol =
          (calculatedSingleDoseMg * formulation.perVolumeMl) / formulation.strengthMg;
        volumePerDoseMl = Number(rawVol.toFixed(2));
        const isDrops = formulation.form === "drops" || formulation.perVolumeMl <= 1;
        roundedVolumePerDoseMl = roundVolumeSafely(volumePerDoseMl, isDrops);
      }
    } else if (
      formulation.form === "tablet" ||
      formulation.form === "dispersible"
    ) {
      if (formulation.strengthMg > 0) {
        const rawTabs = calculatedSingleDoseMg / formulation.strengthMg;
        tabletsPerDose = Number(rawTabs.toFixed(2));
        roundedTabletsPerDose = roundTabletsSafely(rawTabs, formulation.isScored);
      }
    }
  }

  // Primary display text
  let displayDosePrimary = "";
  let displayDoseSecondary = "";

  if (roundedVolumePerDoseMl !== null) {
    displayDosePrimary = `${roundedVolumePerDoseMl} mL`;
    if (calculatedSingleDoseMg !== null) {
      displayDoseSecondary = `${Math.round(calculatedSingleDoseMg)} mg per dose (${
        dosesPerDay > 1 ? `${Math.round(calculatedDailyDoseMg || 0)} mg/day, ` : ""
      }${frequencyText})`;
    } else {
      displayDoseSecondary = frequencyText;
    }
  } else if (roundedTabletsPerDose !== null) {
    const tabWord = roundedTabletsPerDose === 1 ? "Tablet" : "Tablets";
    displayDosePrimary = `${roundedTabletsPerDose} ${tabWord}`;
    if (calculatedSingleDoseMg !== null) {
      displayDoseSecondary = `${Math.round(calculatedSingleDoseMg)} mg per dose (${
        dosesPerDay > 1 ? `${Math.round(calculatedDailyDoseMg || 0)} mg/day, ` : ""
      }${frequencyText})`;
    } else {
      displayDoseSecondary = frequencyText;
    }
  } else if (calculatedSingleDoseMg !== null) {
    displayDosePrimary = `${Math.round(calculatedSingleDoseMg)} mg`;
    displayDoseSecondary = `${frequencyText} (${Math.round(
      calculatedDailyDoseMg || calculatedSingleDoseMg
    )} mg/day)`;
  } else {
    displayDosePrimary = "Consult Protocol";
    displayDoseSecondary = frequencyText;
  }

  return {
    isSafe: hardStops.length === 0,
    hardStops,
    softWarnings,
    singleDoseMg: calculatedSingleDoseMg !== null ? Number(calculatedSingleDoseMg.toFixed(1)) : null,
    dailyDoseMg: calculatedDailyDoseMg !== null ? Number(calculatedDailyDoseMg.toFixed(1)) : null,
    dosesPerDay,
    frequencyText,
    typicalDurationDays,
    formulation,
    volumePerDoseMl,
    roundedVolumePerDoseMl,
    tabletsPerDose,
    roundedTabletsPerDose,
    displayDosePrimary,
    displayDoseSecondary,
    formulaApplied,
    isCappedAtMaxSingle,
    isCappedAtMaxDaily,
    counsellingNotes: drug.counsellingNotes,
    clinicalWarnings: drug.warnings,
    sourceReference: drug.sourceReference,
    disclaimer:
      "For professional use only. Supports, and never replaces, the clinical judgment of a licensed healthcare professional. Always verify against the product label and NAFDAC leaflet.",
  };
}
