import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { calculations } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const email = searchParams.get("email");
  const limit = Math.min(Number(searchParams.get("limit") || 10), 50);

  try {
    let query = db.select().from(calculations);

    const rows = email
      ? await query.where(eq(calculations.staffEmail, email)).orderBy(desc(calculations.createdAt)).limit(limit)
      : await query.orderBy(desc(calculations.createdAt)).limit(limit);

    const formatted = rows.map((r) => ({
      id: r.id,
      drugId: r.drugId,
      drugName: r.drugName,
      patientAgeMonths: Number(r.patientAgeMonths),
      patientWeightKg: Number(r.patientWeightKg),
      formulationLabel: r.formulationLabel,
      calculatedDoseMg: r.calculatedDoseMg ? Number(r.calculatedDoseMg) : null,
      calculatedVolumeMl: r.calculatedVolumeMl ? Number(r.calculatedVolumeMl) : null,
      calculatedTablets: r.calculatedTablets ? Number(r.calculatedTablets) : null,
      frequencyText: r.frequencyText,
      durationDays: r.durationDays,
      dailyTotalMg: r.dailyTotalMg ? Number(r.dailyTotalMg) : null,
      safetyStatus: r.safetyStatus,
      safetyNotes: r.safetyNotes || [],
      staffEmail: r.staffEmail,
      staffName: r.staffName,
      staffRole: r.staffRole,
      createdAt: r.createdAt.toISOString(),
    }));

    return NextResponse.json({
      success: true,
      calculations: formatted,
    });
  } catch (error) {
    console.error("Failed to query recent calculations:", error);
    return NextResponse.json({
      success: true,
      calculations: [],
      warning: "Database calculation history temporarily unavailable",
    });
  }
}
