import {
  pgTable,
  text,
  timestamp,
  boolean,
  integer,
  numeric,
  uuid,
  jsonb,
  pgEnum,
} from "drizzle-orm/pg-core";

export const calcMethodEnum = pgEnum("calc_method", [
  "mg_per_kg",
  "weight_band",
  "age_band",
  "volume_per_kg",
  "fixed",
]);

export const doseBasisEnum = pgEnum("dose_basis", [
  "per_dose",
  "per_day",
]);

export const staffRoleEnum = pgEnum("staff_role", [
  "pharmacist",
  "nurse",
  "ppmv",
  "admin",
]);

export const staffProfiles = pgTable("staff_profiles", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  role: staffRoleEnum("role").notNull().default("pharmacist"),
  facilityName: text("facility_name").notNull().default("ZENCARE Pharmacy & Supermarket"),
  licenseNumber: text("license_number"),
  avatarUrl: text("avatar_url"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const drugs = pgTable("drugs", {
  id: uuid("id").defaultRandom().primaryKey(),
  genericName: text("generic_name").notNull(),
  brandNames: text("brand_names").array().default([]).notNull(),
  drugClass: text("drug_class").notNull(),
  calcMethod: calcMethodEnum("calc_method").notNull(),
  doseBasis: doseBasisEnum("dose_basis").notNull().default("per_dose"),

  // mg/kg dosing
  doseMinMgPerKg: numeric("dose_min_mg_per_kg", { precision: 8, scale: 2 }),
  doseMaxMgPerKg: numeric("dose_max_mg_per_kg", { precision: 8, scale: 2 }),
  dosesPerDayMin: integer("doses_per_day_min"),
  dosesPerDayMax: integer("doses_per_day_max"),
  frequencyText: text("frequency_text").notNull(),
  typicalDurationDays: integer("typical_duration_days"),

  // safety limits
  maxSingleDoseMg: numeric("max_single_dose_mg", { precision: 10, scale: 2 }),
  maxDailyDoseMg: numeric("max_daily_dose_mg", { precision: 10, scale: 2 }),
  maxDailyMgPerKg: numeric("max_daily_mg_per_kg", { precision: 8, scale: 2 }),
  minAgeMonths: numeric("min_age_months", { precision: 6, scale: 1 }).default("0").notNull(),
  minWeightKg: numeric("min_weight_kg", { precision: 6, scale: 2 }),
  maxWeightKg: numeric("max_weight_kg", { precision: 6, scale: 2 }),

  // weight/age band rules (for Coartem, zinc, cetirizine, albendazole, etc.)
  bandRules: jsonb("band_rules"),

  // clinical text
  indications: text("indications").notNull(),
  contraindications: text("contraindications").notNull(),
  warnings: text("warnings").notNull(),
  counsellingNotes: text("counselling_notes").notNull(),

  // Nigeria-specific
  nafdacOtc: boolean("nafdac_otc").default(false).notNull(),
  ppmvAllowed: boolean("ppmv_allowed").default(false).notNull(),
  prescriptionOnly: boolean("prescription_only").default(true).notNull(),

  // governance
  sourceReference: text("source_reference").notNull(),
  lastReviewedAt: text("last_reviewed_at").notNull(),
  reviewedBy: text("reviewed_by").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const drugFormulations = pgTable("drug_formulations", {
  id: uuid("id").defaultRandom().primaryKey(),
  drugId: uuid("drug_id")
    .references(() => drugs.id, { onDelete: "cascade" })
    .notNull(),
  form: text("form").notNull(), // 'syrup' | 'suspension' | 'tablet' | 'dispersible' | 'drops' | 'sachet'
  strengthMg: numeric("strength_mg", { precision: 10, scale: 2 }).notNull(),
  perVolumeMl: numeric("per_volume_ml", { precision: 8, scale: 2 }),
  labelText: text("label_text").notNull(),
  isScored: boolean("is_scored").default(false).notNull(),
  isDefault: boolean("is_default").default(false).notNull(),
});

export const calculations = pgTable("calculations", {
  id: uuid("id").defaultRandom().primaryKey(),
  drugId: uuid("drug_id").references(() => drugs.id, { onDelete: "set null" }),
  drugName: text("drug_name").notNull(),
  patientAgeMonths: numeric("patient_age_months", { precision: 6, scale: 1 }).notNull(),
  patientWeightKg: numeric("patient_weight_kg", { precision: 6, scale: 2 }).notNull(),
  formulationLabel: text("formulation_label").notNull(),
  calculatedDoseMg: numeric("calculated_dose_mg", { precision: 10, scale: 2 }),
  calculatedVolumeMl: numeric("calculated_volume_ml", { precision: 8, scale: 2 }),
  calculatedTablets: numeric("calculated_tablets", { precision: 6, scale: 2 }),
  frequencyText: text("frequency_text").notNull(),
  durationDays: integer("duration_days"),
  dailyTotalMg: numeric("daily_total_mg", { precision: 10, scale: 2 }),
  safetyStatus: text("safety_status").notNull().default("normal"), // 'normal' | 'warning' | 'hard_stop'
  safetyNotes: text("safety_notes").array(),
  staffEmail: text("staff_email").notNull(),
  staffName: text("staff_name").notNull(),
  staffRole: text("staff_role").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
