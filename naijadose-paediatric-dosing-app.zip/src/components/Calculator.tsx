"use client";

import React, { useState, useEffect, useMemo } from "react";
import { Drug, DrugFormulation, CalculationResult, StaffProfile, StoredCalculation } from "@/lib/types";
import { calculateDose } from "@/lib/doseEngine";
import { checkWeightPlausibility, estimateWeightFromAge } from "@/lib/whoGrowth";
import ResultCard from "./ResultCard";
import {
  Scale,
  Calendar,
  Pill,
  Search,
  Sparkles,
  AlertTriangle,
  RotateCcw,
  HelpCircle,
  Check,
  ChevronRight,
  Zap,
} from "lucide-react";

interface CalculatorProps {
  drugs: Drug[];
  currentStaff: StaffProfile;
  onCalculationSaved: (calc: StoredCalculation) => void;
  recentCalculations: StoredCalculation[];
  initialDrug?: Drug | null;
  initialWeight?: number;
  initialAgeMonths?: number;
}

export default function Calculator({
  drugs,
  currentStaff,
  onCalculationSaved,
  recentCalculations,
  initialDrug,
  initialWeight,
  initialAgeMonths,
}: CalculatorProps) {
  // Primary inputs
  const [selectedDrugId, setSelectedDrugId] = useState<string>(
    initialDrug?.id || drugs[0]?.id || ""
  );
  const [weightKg, setWeightKg] = useState<string>(
    initialWeight ? String(initialWeight) : "12.0"
  );
  const [ageYears, setAgeYears] = useState<number>(
    initialAgeMonths !== undefined ? Math.floor(initialAgeMonths / 12) : 2
  );
  const [ageMonths, setAgeMonths] = useState<number>(
    initialAgeMonths !== undefined ? initialAgeMonths % 12 : 0
  );

  // Formulation selection
  const [selectedFormulationId, setSelectedFormulationId] = useState<string>("");
  const [customMgPerKg, setCustomMgPerKg] = useState<number | null>(null);

  // Search filter for drug picker
  const [drugSearch, setDrugSearch] = useState("");
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Active calculation output
  const [calcResult, setCalcResult] = useState<CalculationResult | null>(null);
  const [hasCalculated, setHasCalculated] = useState(false);

  // Current selected drug object
  const selectedDrug = useMemo(() => {
    return drugs.find((d) => d.id === selectedDrugId) || drugs[0];
  }, [drugs, selectedDrugId]);

  // Available formulations for currently selected drug
  const formulations: DrugFormulation[] = useMemo(() => {
    return selectedDrug?.formulations || [];
  }, [selectedDrug]);

  // Selected formulation object
  const selectedFormulation = useMemo(() => {
    if (selectedFormulationId) {
      const match = formulations.find((f) => f.id === selectedFormulationId);
      if (match) return match;
    }
    // Default to first or flagged default
    return formulations.find((f) => f.isDefault) || formulations[0] || undefined;
  }, [formulations, selectedFormulationId]);

  // Update default formulation on drug change
  useEffect(() => {
    if (formulations.length > 0) {
      const def = formulations.find((f) => f.isDefault) || formulations[0];
      setSelectedFormulationId(def.id);
    }
    // Reset custom mg/kg to max standard
    if (selectedDrug?.doseMaxMgPerKg) {
      setCustomMgPerKg(selectedDrug.doseMaxMgPerKg);
    } else {
      setCustomMgPerKg(null);
    }
  }, [selectedDrugId, formulations, selectedDrug]);

  // Sync initial drug if passed from outside
  useEffect(() => {
    if (initialDrug) {
      setSelectedDrugId(initialDrug.id);
    }
    if (initialWeight) {
      setWeightKg(String(initialWeight));
    }
    if (initialAgeMonths !== undefined) {
      setAgeYears(Math.floor(initialAgeMonths / 12));
      setAgeMonths(initialAgeMonths % 12);
    }
  }, [initialDrug, initialWeight, initialAgeMonths]);

  // WHO weight plausibility check
  const totalMonths = ageYears * 12 + ageMonths;
  const numWeight = parseFloat(weightKg);
  const weightPlausibility = useMemo(() => {
    if (isNaN(numWeight) || numWeight <= 0) return null;
    return checkWeightPlausibility(totalMonths, numWeight);
  }, [totalMonths, numWeight]);

  // Check for duplicate active ingredient in recent session
  const duplicateAlert = useMemo(() => {
    if (!selectedDrug || recentCalculations.length === 0) return null;
    const drugName = selectedDrug.genericName.toLowerCase();
    const isParacetamol = drugName.includes("paracetamol") || drugName.includes("acetaminophen");

    const recentSame = recentCalculations.find((c) => {
      const name = c.drugName.toLowerCase();
      if (isParacetamol && (name.includes("paracetamol") || name.includes("acetaminophen"))) {
        return true;
      }
      return c.drugId === selectedDrug.id;
    });

    if (recentSame) {
      return `⚠️ Duplicate Medication Alert: ${recentSame.drugName} was already calculated within your recent session. Beware of inadvertent toxic duplication.`;
    }
    return null;
  }, [selectedDrug, recentCalculations]);

  // Perform calculation
  const handleCalculate = () => {
    if (!selectedDrug || isNaN(numWeight) || numWeight <= 0) return;

    const result = calculateDose({
      drug: selectedDrug,
      weightKg: numWeight,
      ageYears,
      ageMonths,
      selectedFormulation,
      doseSelectedMgPerKg: customMgPerKg || undefined,
    });

    setCalcResult(result);
    setHasCalculated(true);

    // Save to local state / sync audit
    const stored: StoredCalculation = {
      id: "calc-" + Date.now(),
      drugId: selectedDrug.id,
      drugName: selectedDrug.genericName,
      patientAgeMonths: totalMonths,
      patientWeightKg: numWeight,
      formulationLabel:
        result.formulation?.labelText || "Standard Formulation / Protocol",
      calculatedDoseMg: result.singleDoseMg,
      calculatedVolumeMl: result.roundedVolumePerDoseMl,
      calculatedTablets: result.roundedTabletsPerDose,
      frequencyText: result.frequencyText,
      durationDays: result.typicalDurationDays,
      dailyTotalMg: result.dailyDoseMg,
      safetyStatus: !result.isSafe
        ? "hard_stop"
        : result.softWarnings.length > 0
        ? "warning"
        : "normal",
      safetyNotes: [
        ...result.hardStops.map((h) => h.message),
        ...result.softWarnings.map((w) => w.message),
      ],
      staffEmail: currentStaff.email,
      staffName: currentStaff.fullName,
      staffRole: currentStaff.role,
      createdAt: new Date().toISOString(),
    };

    onCalculationSaved(stored);

    // Asynchronously log to API
    fetch("/api/calculate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        drug: selectedDrug,
        weightKg: numWeight,
        ageYears,
        ageMonths,
        selectedFormulation,
        doseSelectedMgPerKg: customMgPerKg,
        staffEmail: currentStaff.email,
        staffName: currentStaff.fullName,
        staffRole: currentStaff.role,
      }),
    }).catch((err) => console.warn("Background log error:", err));
  };

  // Quick weight adjuster
  const adjustWeight = (delta: number) => {
    const current = isNaN(numWeight) ? 10 : numWeight;
    const next = Math.max(1.0, Math.min(120, Number((current + delta).toFixed(1))));
    setWeightKg(String(next));
  };

  // Use APLS estimated weight
  const applyEstimatedWeight = () => {
    const est = estimateWeightFromAge(totalMonths);
    setWeightKg(String(est.estimatedKg));
  };

  // Quick-select chips for top paediatric drugs
  const popularChips = [
    { label: "Paracetamol", match: "Paracetamol" },
    { label: "Coartem", match: "Artemether" },
    { label: "Amoxicillin", match: "Amoxicillin" },
    { label: "Ibuprofen", match: "Ibuprofen" },
    { label: "Augmentin", match: "Clavulanate" },
    { label: "Zinc + ORS", match: "Zinc" },
    { label: "Cetirizine", match: "Cetirizine" },
    { label: "Piriton", match: "Chlorpheniramine" },
  ];

  // Filtered drugs for search
  const filteredDrugs = useMemo(() => {
    if (!drugSearch.trim()) return drugs;
    const q = drugSearch.toLowerCase();
    return drugs.filter(
      (d) =>
        d.genericName.toLowerCase().includes(q) ||
        d.brandNames.some((b) => b.toLowerCase().includes(q)) ||
        d.drugClass.toLowerCase().includes(q)
    );
  }, [drugs, drugSearch]);

  return (
    <div className="space-y-5 max-w-4xl mx-auto">
      {/* Input Card */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl shadow-xl p-5 sm:p-6 backdrop-blur-sm space-y-5">
        {/* Step 1: Drug Selection Header & Chips */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <Pill className="w-4 h-4" />
              1. Select Paediatric Drug
            </label>
            <span className="text-[11px] text-slate-400">
              {drugs.length} verified paediatric drugs
            </span>
          </div>

          {/* Quick Select Chips */}
          <div className="flex flex-wrap gap-1.5 mb-3">
            {popularChips.map((chip) => {
              const matchedDrug = drugs.find((d) => d.genericName.includes(chip.match));
              if (!matchedDrug) return null;
              const isSelected = selectedDrug?.id === matchedDrug.id;
              return (
                <button
                  key={chip.label}
                  type="button"
                  onClick={() => {
                    setSelectedDrugId(matchedDrug.id);
                    setHasCalculated(false);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    isSelected
                      ? "bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-900/30 scale-102"
                      : "bg-slate-700/80 hover:bg-slate-700 text-slate-300 border border-slate-600/70"
                  }`}
                >
                  {chip.label}
                </button>
              );
            })}
          </div>

          {/* Search / Select Dropdown */}
          <div className="relative">
            <div className="relative">
              <input
                type="text"
                placeholder="Search drug or brand (e.g. Calpol, Lonart, Fleming, Septrin)..."
                value={drugSearch}
                onChange={(e) => {
                  setDrugSearch(e.target.value);
                  setIsSearchOpen(true);
                }}
                onFocus={() => setIsSearchOpen(true)}
                className="w-full bg-slate-900/90 border border-slate-700 rounded-xl px-4 py-3 pl-10 text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            </div>

            {/* Dropdown List */}
            {isSearchOpen && (
              <>
                <div
                  className="fixed inset-0 z-20"
                  onClick={() => setIsSearchOpen(false)}
                />
                <div className="absolute left-0 right-0 mt-1 max-h-64 overflow-y-auto bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-1 z-30 space-y-1">
                  {filteredDrugs.length > 0 ? (
                    filteredDrugs.map((d) => (
                      <button
                        key={d.id}
                        type="button"
                        onClick={() => {
                          setSelectedDrugId(d.id);
                          setDrugSearch("");
                          setIsSearchOpen(false);
                          setHasCalculated(false);
                        }}
                        className={`w-full text-left p-2.5 rounded-lg flex items-center justify-between text-xs transition ${
                          selectedDrug?.id === d.id
                            ? "bg-emerald-950/70 border border-emerald-500/50 text-emerald-200"
                            : "hover:bg-slate-800 text-slate-200"
                        }`}
                      >
                        <div>
                          <p className="font-bold text-sm text-slate-100">{d.genericName}</p>
                          <p className="text-[11px] text-slate-400 truncate max-w-sm">
                            Brands: {d.brandNames.join(", ")}
                          </p>
                        </div>
                        <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-400 border border-slate-700 shrink-0 ml-2">
                          {d.drugClass}
                        </span>
                      </button>
                    ))
                  ) : (
                    <div className="p-4 text-center text-xs text-slate-400">
                      No matching drug found for "{drugSearch}".
                    </div>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Active Drug Badge & Brand Names */}
          {selectedDrug && (
            <div className="mt-2.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-black text-emerald-400 text-sm">
                    {selectedDrug.genericName}
                  </h2>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    {selectedDrug.drugClass}
                  </span>
                  {selectedDrug.ppmvAllowed && (
                    <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      PPMV Allowed
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  <strong className="text-slate-300">Popular Nigerian brands:</strong>{" "}
                  {selectedDrug.brandNames.slice(0, 4).join(", ")}
                </p>
              </div>

              <div className="text-right text-[11px] text-slate-400 shrink-0">
                <p>NEML / BNFc 2024</p>
                <p className="text-emerald-500 font-medium">Verified by ZENCARE</p>
              </div>
            </div>
          )}
        </div>

        {/* Duplicate alert if present */}
        {duplicateAlert && (
          <div className="p-3 bg-amber-950/40 border border-amber-600/50 rounded-xl text-xs text-amber-200 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>{duplicateAlert}</span>
          </div>
        )}

        {/* Step 2 & 3: Weight and Age Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
          {/* Weight (kg) Input */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Scale className="w-4 h-4" />
                2. Patient Weight (kg)
              </label>
              <button
                type="button"
                onClick={applyEstimatedWeight}
                className="text-[11px] text-emerald-400 hover:text-emerald-300 underline font-medium"
              >
                Estimate from age
              </button>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="number"
                step="0.1"
                min="0.5"
                max="150"
                value={weightKg}
                onChange={(e) => {
                  setWeightKg(e.target.value);
                  setHasCalculated(false);
                }}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-2xl font-black text-white text-center focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
                placeholder="12.0"
              />
              <span className="text-slate-400 font-bold text-sm shrink-0">kg</span>
            </div>

            {/* Quick Increment buttons */}
            <div className="flex items-center justify-between gap-1">
              <button
                type="button"
                onClick={() => adjustWeight(-1.0)}
                className="flex-1 py-1.5 rounded-lg bg-slate-700/80 hover:bg-slate-700 text-xs font-bold text-slate-200 transition"
              >
                -1.0
              </button>
              <button
                type="button"
                onClick={() => adjustWeight(-0.5)}
                className="flex-1 py-1.5 rounded-lg bg-slate-700/80 hover:bg-slate-700 text-xs font-bold text-slate-200 transition"
              >
                -0.5
              </button>
              <button
                type="button"
                onClick={() => adjustWeight(0.5)}
                className="flex-1 py-1.5 rounded-lg bg-slate-700/80 hover:bg-slate-700 text-xs font-bold text-slate-200 transition"
              >
                +0.5
              </button>
              <button
                type="button"
                onClick={() => adjustWeight(1.0)}
                className="flex-1 py-1.5 rounded-lg bg-slate-700/80 hover:bg-slate-700 text-xs font-bold text-slate-200 transition"
              >
                +1.0
              </button>
            </div>

            {/* WHO Plausibility status */}
            {weightPlausibility && (
              <div
                className={`text-[11px] px-3 py-1.5 rounded-lg flex items-start gap-1.5 ${
                  weightPlausibility.isPlausible
                    ? "bg-emerald-950/40 text-emerald-300 border border-emerald-500/30"
                    : "bg-amber-950/40 text-amber-300 border border-amber-600/40"
                }`}
              >
                {weightPlausibility.isPlausible ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>
                      WHO growth standard check: Normal range for age (median ~
                      {weightPlausibility.medianKg} kg)
                    </span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                    <span>{weightPlausibility.message}</span>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Age (Years & Months) Input */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Calendar className="w-4 h-4" />
                3. Patient Age
              </label>
              <span className="text-[11px] text-slate-400">
                Total: {totalMonths} month{totalMonths === 1 ? "" : "s"}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Years</label>
                <div className="flex items-center bg-slate-900 border border-slate-700 rounded-xl overflow-hidden">
                  <button
                    type="button"
                    onClick={() => {
                      setAgeYears(Math.max(0, ageYears - 1));
                      setHasCalculated(false);
                    }}
                    className="px-3 py-3 text-slate-300 hover:bg-slate-800 text-sm font-bold"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="0"
                    max="16"
                    value={ageYears}
                    onChange={(e) => {
                      setAgeYears(Math.max(0, parseInt(e.target.value) || 0));
                      setHasCalculated(false);
                    }}
                    className="w-full bg-transparent text-center font-bold text-white text-lg focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setAgeYears(ageYears + 1);
                      setHasCalculated(false);
                    }}
                    className="px-3 py-3 text-slate-300 hover:bg-slate-800 text-sm font-bold"
                  >
                    +
                  </button>
                </div>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Months (0–11)</label>
                <div className="flex items-center bg-slate-900 border border-slate-700 rounded-xl overflow-hidden">
                  <button
                    type="button"
                    onClick={() => {
                      setAgeMonths(Math.max(0, ageMonths - 1));
                      setHasCalculated(false);
                    }}
                    className="px-3 py-3 text-slate-300 hover:bg-slate-800 text-sm font-bold"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="0"
                    max="11"
                    value={ageMonths}
                    onChange={(e) => {
                      const val = parseInt(e.target.value) || 0;
                      setAgeMonths(Math.min(11, Math.max(0, val)));
                      setHasCalculated(false);
                    }}
                    className="w-full bg-transparent text-center font-bold text-white text-lg focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setAgeMonths(Math.min(11, ageMonths + 1));
                      setHasCalculated(false);
                    }}
                    className="px-3 py-3 text-slate-300 hover:bg-slate-800 text-sm font-bold"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* Neonate Alert */}
            {totalMonths < 1 && (
              <div className="text-[11px] px-3 py-1.5 rounded-lg bg-amber-950/40 text-amber-300 border border-amber-600/40 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Neonate (&lt;1 month): Requires paediatric specialist protocol</span>
              </div>
            )}
          </div>
        </div>

        {/* Step 4: Formulation Selector */}
        {formulations.length > 0 && (
          <div className="pt-2">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                4. Select Product Strength (Formulation in Hand)
              </label>
              <span className="text-[11px] text-slate-400">
                {formulations.length} options available
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {formulations.map((f) => {
                const isSelected = selectedFormulation?.id === f.id;
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => {
                      setSelectedFormulationId(f.id);
                      setHasCalculated(false);
                    }}
                    className={`text-left p-3 rounded-xl border text-xs transition-all ${
                      isSelected
                        ? "bg-emerald-950/60 border-emerald-500 text-emerald-200 shadow-md ring-1 ring-emerald-500"
                        : "bg-slate-900/60 hover:bg-slate-900 border-slate-700/80 text-slate-300"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">{f.labelText}</span>
                      {f.isDefault && (
                        <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/30">
                          Default
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 block mt-1 capitalize">
                      Form: {f.form} {f.isScored ? "(Scored)" : ""}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 5: Dose Range Adjustment (if mg/kg range exists, e.g. Paracetamol 10-15 mg/kg) */}
        {selectedDrug?.calcMethod === "mg_per_kg" &&
          selectedDrug.doseMinMgPerKg &&
          selectedDrug.doseMaxMgPerKg &&
          selectedDrug.doseMinMgPerKg < selectedDrug.doseMaxMgPerKg && (
            <div className="pt-1 bg-slate-900/50 p-3 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-slate-300">
                  Target Dose Rate:{" "}
                  <strong className="text-emerald-400">
                    {customMgPerKg || selectedDrug.doseMaxMgPerKg} mg/kg
                  </strong>
                </span>
                <span className="text-[11px] text-slate-400">
                  Approved range: {selectedDrug.doseMinMgPerKg} –{" "}
                  {selectedDrug.doseMaxMgPerKg} mg/kg
                </span>
              </div>
              <input
                type="range"
                min={selectedDrug.doseMinMgPerKg}
                max={selectedDrug.doseMaxMgPerKg}
                step={0.5}
                value={customMgPerKg || selectedDrug.doseMaxMgPerKg}
                onChange={(e) => {
                  setCustomMgPerKg(parseFloat(e.target.value));
                  setHasCalculated(false);
                }}
                className="w-full accent-emerald-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>{selectedDrug.doseMinMgPerKg} mg/kg (Mild)</span>
                <span>{selectedDrug.doseMaxMgPerKg} mg/kg (Standard/High)</span>
              </div>
            </div>
          )}

        {/* Calculate Button - PRD Requirement: Big, thumb-friendly, under 10 seconds */}
        <button
          type="button"
          onClick={handleCalculate}
          className="w-full py-4 rounded-xl font-black text-base text-slate-950 bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-400 hover:from-emerald-300 hover:to-teal-200 shadow-xl shadow-emerald-950/60 active:scale-[0.99] transition-all flex items-center justify-center gap-2"
        >
          <Zap className="w-5 h-5 fill-slate-950" />
          <span>CALCULATE PAEDIATRIC DOSE</span>
        </button>
      </div>

      {/* Result Card Display */}
      {hasCalculated && (
        <ResultCard
          result={calcResult}
          drug={selectedDrug}
          weightKg={numWeight}
          ageYears={ageYears}
          ageMonths={ageMonths}
          staff={currentStaff}
        />
      )}
    </div>
  );
}
