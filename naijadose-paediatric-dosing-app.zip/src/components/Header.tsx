"use client";

import React, { useState } from "react";
import { StaffProfile } from "@/lib/types";
import {
  ShieldAlert,
  UserCheck,
  Building2,
  Wifi,
  Sparkles,
  ChevronDown,
  Info,
} from "lucide-react";

interface HeaderProps {
  currentStaff: StaffProfile;
  onSelectStaff: (staff: StaffProfile) => void;
  staffList: StaffProfile[];
  isOnline: boolean;
  onOpenAbout: () => void;
}

export default function Header({
  currentStaff,
  onSelectStaff,
  staffList,
  isOnline,
  onOpenAbout,
}: HeaderProps) {
  const [showStaffDropdown, setShowStaffDropdown] = useState(false);

  const getRoleBadge = (role: string) => {
    switch (role) {
      case "pharmacist":
        return {
          label: "Pharmacist",
          color: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
        };
      case "nurse":
        return {
          label: "Clinic Nurse",
          color: "bg-cyan-500/20 text-cyan-300 border-cyan-500/40",
        };
      case "ppmv":
        return {
          label: "PPMV Operator",
          color: "bg-amber-500/20 text-amber-300 border-amber-500/40",
        };
      default:
        return {
          label: "Clinical Lead",
          color: "bg-purple-500/20 text-purple-300 border-purple-500/40",
        };
    }
  };

  const currentRoleBadge = getRoleBadge(currentStaff.role);

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 shadow-md">
      {/* Disclaimer Banner - PRD Mandated */}
      <div className="bg-amber-500/15 border-b border-amber-500/30 px-3 py-1.5 text-xs text-amber-200 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 font-medium truncate">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="truncate">
            <strong className="text-amber-300">FOR PROFESSIONAL USE ONLY:</strong> Supports, never replaces, clinical judgment. Verify with NAFDAC leaflet & NEML.
          </span>
        </div>
        <button
          onClick={onOpenAbout}
          className="text-amber-300 hover:text-white underline text-[11px] shrink-0 font-semibold"
        >
          Guidelines
        </button>
      </div>

      {/* Main Bar */}
      <div className="max-w-4xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
        {/* Brand & Title */}
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 p-0.5 shadow-lg shadow-emerald-900/40 flex items-center justify-center">
            <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center">
              <span className="text-emerald-400 font-black text-xl tracking-tighter">₦D</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-lg tracking-tight text-white flex items-center gap-1">
                Naija<span className="text-emerald-400">Dose</span>
              </h1>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.2 rounded font-mono font-medium">
                v1.0 MVP
              </span>
            </div>
            <p className="text-[11px] text-slate-400 flex items-center gap-1">
              <Building2 className="w-3 h-3 text-slate-500" />
              ZENCARE Pharmacy & Supermarket
            </p>
          </div>
        </div>

        {/* Staff Switcher & Network */}
        <div className="flex items-center gap-2">
          {/* Offline/Online indicator */}
          <div
            title={isOnline ? "Online & Synchronized" : "Offline Mode (Sub-10ms Local Engine Active)"}
            className={`hidden sm:flex items-center gap-1 px-2 py-1 rounded-full text-[11px] font-medium border ${
              isOnline
                ? "bg-slate-800 text-emerald-400 border-emerald-500/30"
                : "bg-amber-950/40 text-amber-300 border-amber-600/40"
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                isOnline ? "bg-emerald-400 animate-pulse" : "bg-amber-400"
              }`}
            />
            <span>{isOnline ? "Live" : "Offline PWA"}</span>
          </div>

          {/* Persona Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowStaffDropdown(!showStaffDropdown)}
              className="flex items-center gap-1.5 bg-slate-800/90 hover:bg-slate-800 text-left border border-slate-700 hover:border-slate-600 px-2.5 py-1.5 rounded-lg transition-all"
            >
              <span className="text-base leading-none">{currentStaff.avatarUrl || "👨🏾‍⚕️"}</span>
              <div className="hidden xs:block text-left">
                <p className="text-xs font-semibold text-slate-200 leading-tight truncate max-w-[110px]">
                  {currentStaff.fullName.split(" ")[0]} {currentStaff.fullName.split(" ")[1]}
                </p>
                <span
                  className={`text-[9px] uppercase font-bold tracking-wider px-1 rounded inline-block border ${currentRoleBadge.color}`}
                >
                  {currentRoleBadge.label}
                </span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-0.5" />
            </button>

            {/* Dropdown Menu */}
            {showStaffDropdown && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setShowStaffDropdown(false)}
                />
                <div className="absolute right-0 mt-2 w-72 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl p-2 z-50 text-slate-200">
                  <div className="px-2 py-1.5 border-b border-slate-700/80 mb-1">
                    <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      Switch Staff Persona
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Adapts role-based view and PCN scope
                    </p>
                  </div>
                  <div className="space-y-1">
                    {staffList.map((staff) => {
                      const isCurrent = staff.id === currentStaff.id;
                      const badge = getRoleBadge(staff.role);
                      return (
                        <button
                          key={staff.id}
                          onClick={() => {
                            onSelectStaff(staff);
                            setShowStaffDropdown(false);
                          }}
                          className={`w-full text-left p-2 rounded-lg flex items-start gap-2.5 transition-colors ${
                            isCurrent
                              ? "bg-emerald-950/60 border border-emerald-500/40 text-emerald-200"
                              : "hover:bg-slate-700/60 text-slate-300"
                          }`}
                        >
                          <span className="text-xl shrink-0 mt-0.5">{staff.avatarUrl || "🧑🏾‍⚕️"}</span>
                          <div className="truncate">
                            <div className="flex items-center gap-1.5">
                              <p className="text-xs font-semibold text-white truncate">
                                {staff.fullName}
                              </p>
                              {isCurrent && (
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                              )}
                            </div>
                            <p className="text-[11px] text-slate-400 truncate">
                              {staff.facilityName}
                            </p>
                            <span
                              className={`text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.2 rounded mt-0.5 inline-block border ${badge.color}`}
                            >
                              {badge.label}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
