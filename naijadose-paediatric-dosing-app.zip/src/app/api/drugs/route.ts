import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { drugs, drugFormulations } from "@/db/schema";
import { STARTER_DRUGS } from "@/lib/starterDrugs";
import { eq, ilike, or } from "drizzle-orm";
import { DrugWithFormulations } from "@/lib/starterDrugs";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get("q")?.toLowerCase().trim() || "";
  const filterClass = searchParams.get("class") || "";
  const ppmvOnly = searchParams.get("ppmv") === "true";

  try {
    const allDrugs = await db.select().from(drugs);
    const allFormulations = await db.select().from(drugFormulations);

    // Map formulations to drugs
    const combined: DrugWithFormulations[] = allDrugs.map((d) => {
      const forms = allFormulations
        .filter((f) => f.drugId === d.id)
        .map((f) => ({
          id: f.id,
          drugId: f.drugId,
          form: f.form as any,
          strengthMg: Number(f.strengthMg),
          perVolumeMl: f.perVolumeMl ? Number(f.perVolumeMl) : null,
          labelText: f.labelText,
          isScored: f.isScored,
          isDefault: f.isDefault,
        }));

      return {
        id: d.id,
        genericName: d.genericName,
        brandNames: d.brandNames || [],
        drugClass: d.drugClass,
        calcMethod: d.calcMethod as any,
        doseBasis: d.doseBasis as any,
        doseMinMgPerKg: d.doseMinMgPerKg ? Number(d.doseMinMgPerKg) : null,
        doseMaxMgPerKg: d.doseMaxMgPerKg ? Number(d.doseMaxMgPerKg) : null,
        dosesPerDayMin: d.dosesPerDayMin,
        dosesPerDayMax: d.dosesPerDayMax,
        frequencyText: d.frequencyText,
        typicalDurationDays: d.typicalDurationDays,
        maxSingleDoseMg: d.maxSingleDoseMg ? Number(d.maxSingleDoseMg) : null,
        maxDailyDoseMg: d.maxDailyDoseMg ? Number(d.maxDailyDoseMg) : null,
        maxDailyMgPerKg: d.maxDailyMgPerKg ? Number(d.maxDailyMgPerKg) : null,
        minAgeMonths: Number(d.minAgeMonths || 0),
        minWeightKg: d.minWeightKg ? Number(d.minWeightKg) : null,
        maxWeightKg: d.maxWeightKg ? Number(d.maxWeightKg) : null,
        bandRules: d.bandRules as any,
        indications: d.indications,
        contraindications: d.contraindications,
        warnings: d.warnings,
        counsellingNotes: d.counsellingNotes,
        nafdacOtc: d.nafdacOtc,
        ppmvAllowed: d.ppmvAllowed,
        prescriptionOnly: d.prescriptionOnly,
        sourceReference: d.sourceReference,
        lastReviewedAt: d.lastReviewedAt,
        reviewedBy: d.reviewedBy,
        isActive: d.isActive,
        formulations: forms,
      };
    });

    let result = combined;

    if (query) {
      result = result.filter(
        (d) =>
          d.genericName.toLowerCase().includes(query) ||
          d.brandNames.some((b) => b.toLowerCase().includes(query)) ||
          d.drugClass.toLowerCase().includes(query)
      );
    }

    if (filterClass && filterClass !== "all") {
      result = result.filter((d) =>
        d.drugClass.toLowerCase().includes(filterClass.toLowerCase())
      );
    }

    if (ppmvOnly) {
      result = result.filter((d) => d.ppmvAllowed);
    }

    return NextResponse.json({
      success: true,
      count: result.length,
      drugs: result,
    });
  } catch (error) {
    console.error("Database query failed, falling back to local dataset:", error);
    // Fallback to embedded STARTER_DRUGS
    let fallback = STARTER_DRUGS;
    if (query) {
      fallback = fallback.filter(
        (d) =>
          d.genericName.toLowerCase().includes(query) ||
          d.brandNames.some((b) => b.toLowerCase().includes(query)) ||
          d.drugClass.toLowerCase().includes(query)
      );
    }
    if (filterClass && filterClass !== "all") {
      fallback = fallback.filter((d) =>
        d.drugClass.toLowerCase().includes(filterClass.toLowerCase())
      );
    }
    if (ppmvOnly) {
      fallback = fallback.filter((d) => d.ppmvAllowed);
    }

    return NextResponse.json({
      success: true,
      count: fallback.length,
      drugs: fallback,
      source: "embedded_fallback",
    });
  }
}
