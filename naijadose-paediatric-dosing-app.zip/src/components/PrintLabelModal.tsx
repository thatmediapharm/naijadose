"use client";

import React from "react";
import { CalculationResult, Drug, StaffProfile } from "@/lib/types";
import { Printer, X, ShieldAlert, Sparkles, Building2, Check } from "lucide-react";

interface PrintLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  drug: Drug;
  result: CalculationResult;
  weightKg: number;
  ageYears: number;
  ageMonths: number;
  staff: StaffProfile;
}

export default function PrintLabelModal({
  isOpen,
  onClose,
  drug,
  result,
  weightKg,
  ageYears,
  ageMonths,
  staff,
}: PrintLabelModalProps) {
  if (!isOpen) return null;

  const totalAgeMonths = (ageYears || 0) * 12 + (ageMonths || 0);
  const ageDisplay =
    totalAgeMonths < 12
      ? `${totalAgeMonths} month${totalAgeMonths === 1 ? "" : "s"}`
      : `${(totalAgeMonths / 12).toFixed(1).replace(".0", "")} yr${
          totalAgeMonths / 12 > 1 ? "s" : ""
        } (${totalAgeMonths}m)`;

  const handlePrint = () => {
    window.print();
  };

  const currentDate = new Date().toLocaleDateString("en-NG", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm print:p-0 print:bg-white print:fixed">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden print:border-none print:shadow-none print:w-full print:max-w-none print:bg-white print:text-black">
        {/* Modal Header */}
        <div className="px-5 py-3.5 bg-slate-800/80 border-b border-slate-700 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-slate-100 text-sm">
              Print Pharmacy Dispensing Label
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Label Area */}
        <div className="p-6">
          <div
            id="pharmacy-label"
            className="bg-white text-slate-900 rounded-xl p-5 border-2 border-slate-300 shadow-inner font-sans print:border-2 print:border-black print:p-4 print:m-0"
          >
            {/* Pharmacy Banner */}
            <div className="border-b-2 border-slate-900 pb-2 mb-3 text-center">
              <div className="flex items-center justify-center gap-1.5">
                <span className="font-black text-base tracking-tight uppercase text-emerald-800">
                  ZENCARE PHARMACY
                </span>
              </div>
              <p className="text-[10px] text-slate-600 font-medium tracking-wide uppercase">
                {staff.facilityName}
              </p>
              <p className="text-[9px] text-slate-500">
                Lagos • Kano • Enugu | Emergency Tel: 0800-ZENCARE
              </p>
            </div>

            {/* Patient & Dosing Info */}
            <div className="space-y-2.5 text-xs text-slate-800">
              <div className="flex justify-between items-center text-[11px] bg-slate-100 px-2 py-1 rounded border border-slate-200">
                <span>
                  <strong>PATIENT:</strong> Paediatric ({ageDisplay})
                </span>
                <span>
                  <strong>WT:</strong> {weightKg} kg
                </span>
                <span>
                  <strong>DATE:</strong> {currentDate.split(",")[0]}
                </span>
              </div>

              {/* Drug Identification */}
              <div className="pt-1">
                <p className="text-sm font-black text-slate-950 uppercase tracking-tight">
                  {drug.genericName}
                </p>
                <p className="text-[11px] font-semibold text-emerald-900">
                  {result.formulation?.labelText || "Standard Formulation"}
                </p>
              </div>

              {/* Bold Direction */}
              <div className="bg-emerald-50 border-2 border-emerald-600/60 p-2.5 rounded-lg text-center my-2">
                <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-800 block">
                  DIRECTION FOR CAREGIVER
                </span>
                <p className="text-xl font-black text-emerald-950 my-0.5">
                  GIVE {result.displayDosePrimary}
                </p>
                <p className="text-xs font-semibold text-slate-800">
                  {result.frequencyText}
                </p>
                <p className="text-[11px] text-slate-600 mt-0.5 font-medium">
                  Duration: {result.typicalDurationDays} days
                </p>
              </div>

              {/* Counselling & Precautions */}
              <div className="text-[10px] leading-tight text-slate-700 bg-amber-50/60 p-2 rounded border border-amber-200">
                <p className="font-bold text-amber-950">IMPORTANT INSTRUCTIONS:</p>
                <p>{result.counsellingNotes}</p>
                {result.clinicalWarnings && (
                  <p className="mt-1 font-semibold text-amber-900">
                    ⚠️ {result.clinicalWarnings.slice(0, 110)}...
                  </p>
                )}
              </div>

              {/* Dispenser & Standard Footnotes */}
              <div className="border-t border-dashed border-slate-400 pt-2 flex justify-between items-end text-[9px] text-slate-600">
                <div>
                  <p>
                    <strong>Dispensed By:</strong> {staff.fullName}
                  </p>
                  <p>
                    <strong>Reg No:</strong> {staff.licenseNumber || "PCN Verified"}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-red-700 uppercase">Keep out of reach of children</p>
                  <p>Store below 25°C in cool dry place</p>
                </div>
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-400 text-center mt-3 print:hidden">
            Format: Standard 80mm bottle sticker or thermal receipt print.
          </p>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-800/80 border-t border-slate-700 flex justify-end gap-2.5 print:hidden">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-700 transition"
          >
            Close
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2 rounded-xl text-xs font-bold shadow-lg shadow-emerald-900/40 transition active:scale-95"
          >
            <Printer className="w-4 h-4" />
            Print Sticker
          </button>
        </div>
      </div>
    </div>
  );
}
