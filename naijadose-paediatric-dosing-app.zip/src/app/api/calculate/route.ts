import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { calculations } from "@/db/schema";
import { calculateDose } from "@/lib/doseEngine";
import { CalculationInput, Drug } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      drug,
      weightKg,
      ageYears,
      ageMonths,
      selectedFormulation,
      doseSelectedMgPerKg,
      staffEmail = "guest@zencare.ng",
      staffName = "ZENCARE Dispenser",
      staffRole = "pharmacist",
      notes = "",
    } = body;

    if (!drug) {
      return NextResponse.json(
        { success: false, error: "Drug information is required." },
        { status: 400 }
      );
    }

    const calcInput: CalculationInput = {
      drug,
      weightKg: Number(weightKg),
      ageYears: Number(ageYears || 0),
      ageMonths: Number(ageMonths || 0),
      selectedFormulation,
      doseSelectedMgPerKg: doseSelectedMgPerKg ? Number(doseSelectedMgPerKg) : undefined,
    };

    const result = calculateDose(calcInput);

    const safetyStatus =
      result.hardStops.length > 0
        ? "hard_stop"
        : result.softWarnings.length > 0
        ? "warning"
        : "normal";

    const allNotes = [
      ...result.hardStops.map((h) => `[HARD STOP] ${h.title}: ${h.message}`),
      ...result.softWarnings.map((w) => `[WARNING] ${w.title}: ${w.message}`),
    ];

    // Log calculation to database asynchronously
    try {
      await db.insert(calculations).values({
        drugId: drug.id,
        drugName: drug.genericName,
        patientAgeMonths: String((calcInput.ageYears * 12 + calcInput.ageMonths).toFixed(1)),
        patientWeightKg: String(calcInput.weightKg),
        formulationLabel:
          result.formulation?.labelText || "Standard Formulation / Protocol",
        calculatedDoseMg: result.singleDoseMg ? String(result.singleDoseMg) : null,
        calculatedVolumeMl: result.roundedVolumePerDoseMl
          ? String(result.roundedVolumePerDoseMl)
          : null,
        calculatedTablets: result.roundedTabletsPerDose
          ? String(result.roundedTabletsPerDose)
          : null,
        frequencyText: result.frequencyText,
        durationDays: result.typicalDurationDays,
        dailyTotalMg: result.dailyDoseMg ? String(result.dailyDoseMg) : null,
        safetyStatus,
        safetyNotes: allNotes,
        staffEmail,
        staffName,
        staffRole,
        notes,
      });
    } catch (dbErr) {
      console.warn("Could not record calculation audit trail in DB:", dbErr);
    }

    return NextResponse.json({
      success: true,
      result,
    });
  } catch (error: any) {
    console.error("Calculation API error:", error);
    return NextResponse.json(
      { success: false, error: error?.message || "Failed to calculate dose." },
      { status: 500 }
    );
  }
}
