import { NextResponse } from "next/server";
import { db } from "@/db";
import { staffProfiles } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const profiles = await db.select().from(staffProfiles);
    return NextResponse.json({
      success: true,
      staff: profiles,
    });
  } catch (error) {
    console.error("Failed to load staff profiles:", error);
    return NextResponse.json({
      success: true,
      staff: [
        {
          id: "p1",
          email: "ngozi@zencare.ng",
          fullName: "Pharm. Ngozi Adebayo, B.Pharm, MPSN",
          role: "pharmacist",
          facilityName: "ZENCARE Pharmacy (Victoria Island, Lagos)",
          licenseNumber: "PCN/R/44912",
          avatarUrl: "👩🏾‍⚕️",
        },
        {
          id: "p2",
          email: "amina@zencare.ng",
          fullName: "Nurse Amina Bello, RN, RM",
          role: "nurse",
          facilityName: "ZENCARE Outreach Clinic (Kano)",
          licenseNumber: "NMCN/N/88210",
          avatarUrl: "🩺",
        },
        {
          id: "p3",
          email: "emeka@zencare.ng",
          fullName: "Emeka Okafor (Licensed PPMV)",
          role: "ppmv",
          facilityName: "Emeka Chemist & ZENCARE Partner (Enugu)",
          licenseNumber: "PCN/PPMV/0942",
          avatarUrl: "🏪",
        },
      ],
    });
  }
}
