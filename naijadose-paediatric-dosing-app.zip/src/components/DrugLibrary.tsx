"use client";

import React, { useState, useMemo } from "react";
import { Drug } from "@/lib/types";
import {
  Search,
  Filter,
  Pill,
  BookOpen,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  ShieldAlert,
  Info,
  Calendar,
  UserCheck,
  X,
} from "lucide-react";

interface DrugLibraryProps {
  drugs: Drug[];
  onSelectForCalculation: (drug: Drug) => void;
}

export default function DrugLibrary({
  drugs,
  onSelectForCalculation,
}: DrugLibraryProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedClass, setSelectedClass] = useState("all");
  const [ppmvOnly, setPpmvOnly] = useState(false);
  const [activeModalDrug, setActiveModalDrug] = useState<Drug | null>(null);

  // Unique classes
  const drugClasses = useMemo(() => {
    const set = new Set<string>();
    drugs.forEach((d) => set.add(d.drugClass));
    return ["all", ...Array.from(set)];
  }, [drugs]);

  // Filtered drug list
  const filteredDrugs = useMemo(() => {
    return drugs.filter((d) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        d.genericName.toLowerCase().includes(q) ||
        d.brandNames.some((b) => b.toLowerCase().includes(q)) ||
        d.drugClass.toLowerCase().includes(q) ||
        d.indications.toLowerCase().includes(q);

      const matchClass =
        selectedClass === "all" ||
        d.drugClass.toLowerCase().includes(selectedClass.toLowerCase());

      const matchPpmv = !ppmvOnly || d.ppmvAllowed;

      return matchSearch && matchClass && matchPpmv;
    });
  }, [drugs, searchQuery, selectedClass, ppmvOnly]);

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Search & Filters */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-white">
              Paediatric Drug Library (NEML 7th Ed / BNFc)
            </h2>
          </div>
          <span className="text-xs text-slate-400">
            {filteredDrugs.length} of {drugs.length} drugs shown
          </span>
        </div>

        {/* Search bar */}
        <div className="relative">
          <input
            type="text"
            placeholder="Search by generic or Nigerian brand (e.g. Calpol, Lonart, Fleming, Septrin, Flagyl)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 pl-10 text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        </div>

        {/* Filter Chips & PPMV toggle */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex flex-wrap gap-1.5 items-center">
            {drugClasses.map((cls) => (
              <button
                key={cls}
                onClick={() => setSelectedClass(cls)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition capitalize ${
                  selectedClass === cls
                    ? "bg-emerald-500 text-slate-950 font-bold"
                    : "bg-slate-700/70 hover:bg-slate-700 text-slate-300 border border-slate-600/60"
                }`}
              >
                {cls === "all" ? "All Classes" : cls.split("/")[0]}
              </button>
            ))}
          </div>

          <label className="flex items-center gap-2 cursor-pointer bg-slate-900/80 px-2.5 py-1.5 rounded-lg border border-slate-700/80">
            <input
              type="checkbox"
              checked={ppmvOnly}
              onChange={(e) => setPpmvOnly(e.target.checked)}
              className="accent-emerald-500 rounded cursor-pointer"
            />
            <span className="text-xs text-slate-300 font-medium">
              PPMV Scope Only
            </span>
          </label>
        </div>
      </div>

      {/* Drug Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filteredDrugs.map((drug) => (
          <div
            key={drug.id}
            className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-slate-600 rounded-2xl p-4 shadow-md transition flex flex-col justify-between space-y-3"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-bold text-slate-100 text-sm">
                    {drug.genericName}
                  </h3>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                    {drug.drugClass}
                  </span>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {drug.ppmvAllowed ? (
                    <span className="text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded font-bold">
                      OTC / PPMV
                    </span>
                  ) : (
                    <span className="text-[9px] bg-purple-500/20 text-purple-300 border border-purple-500/30 px-1.5 py-0.5 rounded font-bold">
                      Rx Only
                    </span>
                  )}
                </div>
              </div>

              {/* Nigerian Brands */}
              <p className="text-xs text-slate-400 mt-2">
                <strong className="text-slate-300">Brands:</strong>{" "}
                {drug.brandNames.slice(0, 4).join(", ")}
              </p>

              {/* Dosing Method & Limits */}
              <div className="mt-2 text-xs bg-slate-900/60 p-2 rounded-lg border border-slate-800 space-y-1">
                <p className="text-slate-300">
                  <strong>Standard:</strong> {drug.frequencyText}
                </p>
                <div className="flex flex-wrap gap-x-3 text-[11px] text-slate-400">
                  <span>
                    Min Age: {drug.minAgeMonths === 0 ? "Birth" : `${drug.minAgeMonths}m`}
                  </span>
                  {drug.minWeightKg && <span>Min Wt: {drug.minWeightKg} kg</span>}
                  {drug.maxSingleDoseMg && <span>Max: {drug.maxSingleDoseMg} mg</span>}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 pt-1 border-t border-slate-700/60">
              <button
                onClick={() => setActiveModalDrug(drug)}
                className="flex-1 py-1.5 px-3 rounded-lg bg-slate-700 hover:bg-slate-600 text-xs font-semibold text-slate-200 transition text-center"
              >
                View Monograph
              </button>
              <button
                onClick={() => onSelectForCalculation(drug)}
                className="flex-1 py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white transition flex items-center justify-center gap-1 shadow-md shadow-emerald-900/40"
              >
                <span>Calculate</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredDrugs.length === 0 && (
        <div className="p-8 text-center bg-slate-800/40 border border-slate-700/60 rounded-2xl">
          <p className="text-slate-300 font-semibold text-sm">No drugs match your search.</p>
          <p className="text-xs text-slate-400 mt-1">
            Try searching for "Paracetamol", "Coartem", "Amoxicillin", or clear the PPMV filter.
          </p>
        </div>
      )}

      {/* Clinical Monograph Modal */}
      {activeModalDrug && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="p-4 bg-slate-800 border-b border-slate-700 flex items-start justify-between gap-3">
              <div>
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                  {activeModalDrug.drugClass}
                </span>
                <h3 className="font-black text-lg text-white">
                  {activeModalDrug.genericName}
                </h3>
                <p className="text-xs text-slate-400">
                  Brands: {activeModalDrug.brandNames.join(", ")}
                </p>
              </div>
              <button
                onClick={() => setActiveModalDrug(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-300">
              {/* Formulations available in Nigeria */}
              <div>
                <h4 className="font-bold text-slate-100 uppercase tracking-wider text-[11px] mb-1.5 flex items-center gap-1">
                  <Pill className="w-3.5 h-3.5 text-emerald-400" />
                  Nigerian Formulations & Strengths
                </h4>
                <div className="space-y-1">
                  {activeModalDrug.formulations?.map((f) => (
                    <div
                      key={f.id}
                      className="p-2 rounded bg-slate-800/80 border border-slate-700/60 flex items-center justify-between"
                    >
                      <span className="font-semibold text-white">{f.labelText}</span>
                      <span className="text-[10px] text-slate-400 uppercase">
                        {f.form} {f.isScored ? "(Scored)" : ""}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Indications */}
              <div>
                <h4 className="font-bold text-slate-100 uppercase tracking-wider text-[11px] mb-1">
                  Approved Paediatric Indications
                </h4>
                <p className="bg-slate-800/40 p-2.5 rounded-lg border border-slate-800">
                  {activeModalDrug.indications}
                </p>
              </div>

              {/* Contraindications */}
              <div>
                <h4 className="font-bold text-rose-300 uppercase tracking-wider text-[11px] mb-1 flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                  Contraindications & Black-Box Cautions
                </h4>
                <p className="bg-rose-950/30 text-rose-200 p-2.5 rounded-lg border border-rose-900/40">
                  {activeModalDrug.contraindications}
                </p>
              </div>

              {/* Counselling Notes */}
              <div>
                <h4 className="font-bold text-slate-100 uppercase tracking-wider text-[11px] mb-1">
                  Caregiver Administration & Storage
                </h4>
                <p className="bg-slate-800/40 p-2.5 rounded-lg border border-slate-800">
                  {activeModalDrug.counsellingNotes}
                </p>
              </div>

              {/* Governance & Reference */}
              <div className="bg-slate-800 p-3 rounded-xl border border-slate-700/80 space-y-1 text-[11px] text-slate-400">
                <p>
                  <strong>Clinical Source:</strong> {activeModalDrug.sourceReference}
                </p>
                <p>
                  <strong>Reviewed By:</strong> {activeModalDrug.reviewedBy}
                </p>
                <p>
                  <strong>Last Clinical Review:</strong> {activeModalDrug.lastReviewedAt}
                </p>
              </div>
            </div>

            {/* Footer */}
            <div className="p-3 bg-slate-800 border-t border-slate-700 flex justify-end gap-2">
              <button
                onClick={() => setActiveModalDrug(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-700"
              >
                Close
              </button>
              <button
                onClick={() => {
                  onSelectForCalculation(activeModalDrug);
                  setActiveModalDrug(null);
                }}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-900/40"
              >
                Calculate Dose for this Drug
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
