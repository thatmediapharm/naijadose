"use client";

import React, { useState, useEffect } from "react";
import Header from "@/components/Header";
import Calculator from "@/components/Calculator";
import DrugLibrary from "@/components/DrugLibrary";
import RecentCalculations from "@/components/RecentCalculations";
import WeightEstimator from "@/components/WeightEstimator";
import AboutModal from "@/components/AboutModal";
import { STARTER_DRUGS } from "@/lib/starterDrugs";
import { Drug, StaffProfile, StoredCalculation } from "@/lib/types";
import { Calculator as CalcIcon, BookOpen, Clock, Scale, Info } from "lucide-react";

type ActiveTab = "calculator" | "library" | "recent" | "weight";

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("calculator");
  const [drugs, setDrugs] = useState<Drug[]>(STARTER_DRUGS);
  const [isOnline, setIsOnline] = useState(true);
  const [isAboutOpen, setIsAboutOpen] = useState(false);

  // Staff Profiles
  const defaultStaffList: StaffProfile[] = [
    {
      id: "p1",
      email: "ngozi@zencare.ng",
      fullName: "Pharm. Ngozi Adebayo, B.Pharm, MPSN",
      role: "pharmacist",
      facilityName: "ZENCARE Pharmacy (Victoria Island, Lagos)",
      licenseNumber: "PCN/R/44912",
      avatarUrl: "👩🏾‍⚕️",
    },
    {
      id: "p2",
      email: "amina@zencare.ng",
      fullName: "Nurse Amina Bello, RN, RM",
      role: "nurse",
      facilityName: "ZENCARE Outreach Clinic (Kano)",
      licenseNumber: "NMCN/N/88210",
      avatarUrl: "🩺",
    },
    {
      id: "p3",
      email: "emeka@zencare.ng",
      fullName: "Emeka Okafor (Licensed PPMV)",
      role: "ppmv",
      facilityName: "Emeka Chemist & ZENCARE Partner (Enugu)",
      licenseNumber: "PCN/PPMV/0942",
      avatarUrl: "🏪",
    },
    {
      id: "p4",
      email: "admin@zencare.ng",
      fullName: "Pharm. Chinedu Eze, FPSN (Clinical Lead)",
      role: "admin",
      facilityName: "ZENCARE Healthcare Systems",
      licenseNumber: "PCN/F/11029",
      avatarUrl: "👨🏾‍⚕️",
    },
  ];

  const [staffList, setStaffList] = useState<StaffProfile[]>(defaultStaffList);
  const [currentStaff, setCurrentStaff] = useState<StaffProfile>(defaultStaffList[0]);

  // Preload drug to calculator
  const [calculatorDrug, setCalculatorDrug] = useState<Drug | null>(null);
  const [calculatorWeight, setCalculatorWeight] = useState<number | undefined>(undefined);
  const [calculatorAgeMonths, setCalculatorAgeMonths] = useState<number | undefined>(undefined);

  // Recent calculations
  const [recentCalculations, setRecentCalculations] = useState<StoredCalculation[]>([]);

  // Monitor network status
  useEffect(() => {
    setIsOnline(navigator.onLine);
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Load drugs & staff from API or fallback to offline local dataset
  useEffect(() => {
    fetch("/api/drugs")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.drugs && data.drugs.length > 0) {
          setDrugs(data.drugs);
        }
      })
      .catch((err) => console.warn("Using offline starter drugs:", err));

    fetch("/api/staff")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.staff && data.staff.length > 0) {
          setStaffList(data.staff);
        }
      })
      .catch((err) => console.warn("Using default staff profiles:", err));

    // Load recent calculations from localStorage
    try {
      const saved = localStorage.getItem("naijadose_recent_calcs");
      if (saved) {
        setRecentCalculations(JSON.parse(saved));
      }
    } catch {
      // ignore
    }
  }, []);

  const handleSaveCalculation = (calc: StoredCalculation) => {
    setRecentCalculations((prev) => {
      const updated = [calc, ...prev.filter((c) => c.id !== calc.id)].slice(0, 15);
      try {
        localStorage.setItem("naijadose_recent_calcs", JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  };

  const handleClearRecent = () => {
    setRecentCalculations([]);
    try {
      localStorage.removeItem("naijadose_recent_calcs");
    } catch {
      // ignore
    }
  };

  const handleReloadRecent = (calc: StoredCalculation) => {
    const matchedDrug = drugs.find((d) => d.id === calc.drugId || d.genericName === calc.drugName);
    if (matchedDrug) {
      setCalculatorDrug(matchedDrug);
      setCalculatorWeight(calc.patientWeightKg);
      setCalculatorAgeMonths(calc.patientAgeMonths);
      setActiveTab("calculator");
    }
  };

  const handleSelectFromLibrary = (drug: Drug) => {
    setCalculatorDrug(drug);
    setActiveTab("calculator");
  };

  const handleUseEstimatedWeight = (weightKg: number, ageMonths: number) => {
    setCalculatorWeight(weightKg);
    setCalculatorAgeMonths(ageMonths);
    setActiveTab("calculator");
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      {/* Top Header */}
      <Header
        currentStaff={currentStaff}
        onSelectStaff={setCurrentStaff}
        staffList={staffList}
        isOnline={isOnline}
        onOpenAbout={() => setIsAboutOpen(true)}
      />

      {/* Main Tab Navigation Bar */}
      <div className="border-b border-slate-800 bg-slate-900/60 sticky top-[73px] z-30 backdrop-blur-md">
        <div className="max-w-4xl mx-auto px-4 flex items-center justify-around sm:justify-start gap-1 sm:gap-4 overflow-x-auto py-2">
          <button
            onClick={() => setActiveTab("calculator")}
            className={`flex items-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition whitespace-nowrap ${
              activeTab === "calculator"
                ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-950/40"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
            }`}
          >
            <CalcIcon className="w-4 h-4" />
            <span>Calculator</span>
          </button>

          <button
            onClick={() => setActiveTab("library")}
            className={`flex items-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition whitespace-nowrap ${
              activeTab === "library"
                ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-950/40"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>15 Drugs Library</span>
          </button>

          <button
            onClick={() => setActiveTab("recent")}
            className={`flex items-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition whitespace-nowrap relative ${
              activeTab === "recent"
                ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-950/40"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Recent</span>
            {recentCalculations.length > 0 && (
              <span className="text-[10px] px-1.5 rounded-full bg-slate-800 text-emerald-300 font-bold border border-slate-700">
                {recentCalculations.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("weight")}
            className={`flex items-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition whitespace-nowrap ${
              activeTab === "weight"
                ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-950/40"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
            }`}
          >
            <Scale className="w-4 h-4" />
            <span>Weight Estimator</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 py-5 pb-20">
        {activeTab === "calculator" && (
          <Calculator
            drugs={drugs}
            currentStaff={currentStaff}
            onCalculationSaved={handleSaveCalculation}
            recentCalculations={recentCalculations}
            initialDrug={calculatorDrug}
            initialWeight={calculatorWeight}
            initialAgeMonths={calculatorAgeMonths}
          />
        )}

        {activeTab === "library" && (
          <DrugLibrary
            drugs={drugs}
            onSelectForCalculation={handleSelectFromLibrary}
          />
        )}

        {activeTab === "recent" && (
          <RecentCalculations
            recent={recentCalculations}
            onReload={handleReloadRecent}
            onClear={handleClearRecent}
            drugs={drugs}
          />
        )}

        {activeTab === "weight" && (
          <WeightEstimator onUseWeight={handleUseEstimatedWeight} />
        )}
      </main>

      {/* Persistent Mobile Bottom Navigation (for quick thumb reach on narrow screens) */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 border-t border-slate-800 backdrop-blur-lg px-2 py-1.5 flex justify-around">
        <button
          onClick={() => setActiveTab("calculator")}
          className={`flex flex-col items-center py-1 px-3 rounded-lg text-[10px] font-bold ${
            activeTab === "calculator" ? "text-emerald-400" : "text-slate-400"
          }`}
        >
          <CalcIcon className="w-5 h-5 mb-0.5" />
          <span>Calculator</span>
        </button>

        <button
          onClick={() => setActiveTab("library")}
          className={`flex flex-col items-center py-1 px-3 rounded-lg text-[10px] font-bold ${
            activeTab === "library" ? "text-emerald-400" : "text-slate-400"
          }`}
        >
          <BookOpen className="w-5 h-5 mb-0.5" />
          <span>Drugs</span>
        </button>

        <button
          onClick={() => setActiveTab("recent")}
          className={`flex flex-col items-center py-1 px-3 rounded-lg text-[10px] font-bold relative ${
            activeTab === "recent" ? "text-emerald-400" : "text-slate-400"
          }`}
        >
          <Clock className="w-5 h-5 mb-0.5" />
          <span>Recent</span>
          {recentCalculations.length > 0 && (
            <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-emerald-400" />
          )}
        </button>

        <button
          onClick={() => setActiveTab("weight")}
          className={`flex flex-col items-center py-1 px-3 rounded-lg text-[10px] font-bold ${
            activeTab === "weight" ? "text-emerald-400" : "text-slate-400"
          }`}
        >
          <Scale className="w-5 h-5 mb-0.5" />
          <span>Weight</span>
        </button>
      </nav>

      {/* Clinical Governance Modal */}
      <AboutModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />
    </div>
  );
}
