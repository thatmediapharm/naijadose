export type CalcMethod =
  | "mg_per_kg"
  | "weight_band"
  | "age_band"
  | "volume_per_kg"
  | "fixed";

export type DoseBasis = "per_dose" | "per_day";

export type StaffRole = "pharmacist" | "nurse" | "ppmv" | "admin";

export interface WeightBandRule {
  minKg: number;
  maxKg: number; // e.g. 15 for 5-<15 kg
  tablets?: number;
  doseMg?: number;
  volumeMl?: number;
  instructions?: string;
}

export interface AgeBandRule {
  minMonths: number;
  maxMonths: number;
  doseMg?: number;
  volumeMl?: number;
  tablets?: number;
  frequencyText?: string;
  maxDailyMg?: number;
  instructions?: string;
}

export interface DrugFormulation {
  id: string;
  drugId: string;
  form: "syrup" | "suspension" | "tablet" | "dispersible" | "drops" | "sachet";
  strengthMg: number; // e.g. 125 for 125 mg / 5 mL, or 500 for 500 mg tablet
  perVolumeMl: number | null; // e.g. 5 for per 5 mL, 1 for drops, null for tablets
  labelText: string; // e.g. "125 mg/5 mL"
  isScored: boolean;
  isDefault?: boolean;
}

export interface Drug {
  id: string;
  genericName: string;
  brandNames: string[];
  drugClass: string;
  calcMethod: CalcMethod;
  doseBasis: DoseBasis;

  // mg/kg dosing
  doseMinMgPerKg?: number | null;
  doseMaxMgPerKg?: number | null;
  dosesPerDayMin?: number | null;
  dosesPerDayMax?: number | null;
  frequencyText: string;
  typicalDurationDays?: number | null;

  // safety limits
  maxSingleDoseMg?: number | null;
  maxDailyDoseMg?: number | null;
  maxDailyMgPerKg?: number | null;
  minAgeMonths: number; // e.g. 0, 1, 3, 6, 12, 24
  minWeightKg?: number | null;
  maxWeightKg?: number | null;

  // band rules
  bandRules?: {
    weightBands?: WeightBandRule[];
    ageBands?: AgeBandRule[];
    schedule?: string;
  } | null;

  // clinical info
  indications: string;
  contraindications: string;
  warnings: string;
  counsellingNotes: string;

  // Nigeria regulatory & scope
  nafdacOtc: boolean;
  ppmvAllowed: boolean;
  prescriptionOnly: boolean;

  // governance
  sourceReference: string;
  lastReviewedAt: string;
  reviewedBy: string;
  isActive: boolean;

  formulations?: DrugFormulation[];
}

export interface CalculationInput {
  drug: Drug;
  weightKg: number;
  ageYears: number;
  ageMonths: number; // additional months 0-11
  formulationId?: string;
  selectedFormulation?: DrugFormulation;
  doseSelectedMgPerKg?: number; // custom within range or default (e.g. 15 for 10-15)
  indicationContext?: string;
}

export interface SafetyAlert {
  type: "hard_stop" | "soft_warning" | "info";
  code: string;
  title: string;
  message: string;
  actionRequired?: string;
}

export interface CalculationResult {
  isSafe: boolean; // false if hard stops present
  hardStops: SafetyAlert[];
  softWarnings: SafetyAlert[];

  // dosing outputs
  singleDoseMg: number | null;
  dailyDoseMg: number | null;
  dosesPerDay: number;
  frequencyText: string;
  typicalDurationDays: number;

  // formulation physical outputs
  formulation: DrugFormulation | null;
  volumePerDoseMl: number | null;
  roundedVolumePerDoseMl: number | null;
  tabletsPerDose: number | null;
  roundedTabletsPerDose: number | null;
  displayDosePrimary: string; // e.g. "6.5 mL" or "1 Tablet"
  displayDoseSecondary: string; // e.g. "162.5 mg per dose (650 mg/day)"

  // audit & transparent clinical logic
  formulaApplied: string;
  isCappedAtMaxSingle: boolean;
  isCappedAtMaxDaily: boolean;

  // clinical counselling & warnings
  counsellingNotes: string;
  clinicalWarnings: string;
  sourceReference: string;
  disclaimer: string;
}

export interface StaffProfile {
  id: string;
  email: string;
  fullName: string;
  role: StaffRole;
  facilityName: string;
  licenseNumber?: string;
  avatarUrl?: string;
}

export interface StoredCalculation {
  id: string;
  drugId: string;
  drugName: string;
  patientAgeMonths: number;
  patientWeightKg: number;
  formulationLabel: string;
  calculatedDoseMg: number | null;
  calculatedVolumeMl: number | null;
  calculatedTablets: number | null;
  frequencyText: string;
  durationDays?: number | null;
  dailyTotalMg?: number | null;
  safetyStatus: "normal" | "warning" | "hard_stop";
  safetyNotes: string[];
  staffEmail: string;
  staffName: string;
  staffRole: string;
  createdAt: string;
}
