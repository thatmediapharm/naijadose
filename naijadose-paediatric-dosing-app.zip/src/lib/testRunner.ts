import { calculateDose, roundVolumeSafely, roundTabletsSafely } from "./doseEngine";
import { checkWeightPlausibility } from "./whoGrowth";
import { STARTER_DRUGS } from "./starterDrugs";

function assert(condition: boolean, msg: string) {
  if (!condition) {
    console.error(`❌ FAILED: ${msg}`);
    throw new Error(msg);
  }
  console.log(`✅ PASSED: ${msg}`);
}

export function runTests() {
  console.log("=== RUNNING NAIJADOSE CLINICAL ENGINE TESTS ===");

  const pcm = STARTER_DRUGS.find((d) => d.genericName.includes("Paracetamol"))!;
  const ibup = STARTER_DRUGS.find((d) => d.genericName.includes("Ibuprofen"))!;
  const coartem = STARTER_DRUGS.find((d) => d.genericName.includes("Artemether"))!;
  const zinc = STARTER_DRUGS.find((d) => d.genericName.includes("Zinc"))!;
  const albendazole = STARTER_DRUGS.find((d) => d.genericName.includes("Albendazole"))!;
  const piriton = STARTER_DRUGS.find((d) => d.genericName.includes("Chlorpheniramine"))!;
  const cotrim = STARTER_DRUGS.find((d) => d.genericName.includes("Cotrimoxazole"))!;
  const ors = STARTER_DRUGS.find((d) => d.genericName.includes("Oral Rehydration"))!;

  // Test 1: Paracetamol 10 kg, 12 months, 15 mg/kg at 125mg/5mL
  // 15 * 10 = 150 mg. Volume at 125mg/5mL = (150 * 5)/125 = 6.0 mL
  const res1 = calculateDose({
    drug: pcm,
    weightKg: 10,
    ageYears: 1,
    ageMonths: 0,
    doseSelectedMgPerKg: 15,
    selectedFormulation: pcm.formulations[0], // 125mg/5mL
  });
  assert(res1.isSafe, "Paracetamol normal calculation is safe");
  assert(res1.singleDoseMg === 150, `PCM single dose is 150 mg (got ${res1.singleDoseMg})`);
  assert(res1.roundedVolumePerDoseMl === 6.0, `PCM volume is 6.0 mL (got ${res1.roundedVolumePerDoseMl})`);

  // Test 2: Hard-stop: Ibuprofen under 3 months
  const res2 = calculateDose({
    drug: ibup,
    weightKg: 4.5,
    ageYears: 0,
    ageMonths: 2,
  });
  assert(!res2.isSafe, "Ibuprofen under 3 months triggers hard stop");
  assert(
    res2.hardStops.some((h) => h.code === "MIN_AGE_RESTRICTION"),
    "Has MIN_AGE_RESTRICTION hard stop"
  );

  // Test 3: Hard-stop: Coartem < 5 kg
  const res3 = calculateDose({
    drug: coartem,
    weightKg: 4.2,
    ageYears: 0,
    ageMonths: 6,
  });
  assert(!res3.isSafe, "Coartem under 5 kg triggers hard stop");
  assert(
    res3.hardStops.some((h) => h.code === "MIN_WEIGHT_RESTRICTION"),
    "Has MIN_WEIGHT_RESTRICTION"
  );

  // Test 4: Coartem weight bands
  // Band 1: 5 - <15 kg => 1 tab
  const res4a = calculateDose({
    drug: coartem,
    weightKg: 12,
    ageYears: 2,
    ageMonths: 0,
  });
  assert(res4a.isSafe && res4a.roundedTabletsPerDose === 1, "Coartem 12 kg gets 1 tablet");

  // Band 2: 15 - <25 kg => 2 tabs
  const res4b = calculateDose({
    drug: coartem,
    weightKg: 20,
    ageYears: 5,
    ageMonths: 0,
  });
  assert(res4b.isSafe && res4b.roundedTabletsPerDose === 2, "Coartem 20 kg gets 2 tablets");

  // Test 5: Soft warning: Weight implausible (40 kg for 2-year old)
  const plausibility = checkWeightPlausibility(24, 40);
  assert(!plausibility.isPlausible, "40 kg is implausible for 24 months");
  const res5 = calculateDose({
    drug: pcm,
    weightKg: 40,
    ageYears: 2,
    ageMonths: 0,
  });
  assert(
    res5.softWarnings.some((w) => w.code === "WEIGHT_IMPLAUSIBLE"),
    "Triggers WEIGHT_IMPLAUSIBLE warning"
  );

  // Test 6: Hard stop: Albendazole under 12 months
  const res6 = calculateDose({
    drug: albendazole,
    weightKg: 8,
    ageYears: 0,
    ageMonths: 9,
  });
  assert(!res6.isSafe, "Albendazole < 12 months triggers hard stop");

  // Test 7: Chlorpheniramine under 2 years hard stop
  const res7 = calculateDose({
    drug: piriton,
    weightKg: 10,
    ageYears: 1,
    ageMonths: 6,
  });
  assert(!res7.isSafe, "Chlorpheniramine < 2 years triggers hard stop");

  // Test 8: Cotrimoxazole under 6 weeks hard stop
  const res8 = calculateDose({
    drug: cotrim,
    weightKg: 3.8,
    ageYears: 0,
    ageMonths: 1, // 4 weeks
  });
  assert(!res8.isSafe, "Cotrimoxazole < 6 weeks triggers hard stop");

  // Test 9: Zinc age bands
  // <6 months => 10 mg
  const res9a = calculateDose({
    drug: zinc,
    weightKg: 5,
    ageYears: 0,
    ageMonths: 4,
  });
  assert(res9a.singleDoseMg === 10, "Zinc <6m gets 10 mg");

  // >=6 months => 20 mg
  const res9b = calculateDose({
    drug: zinc,
    weightKg: 9,
    ageYears: 1,
    ageMonths: 0,
  });
  assert(res9b.singleDoseMg === 20, "Zinc >=6m gets 20 mg");

  // Test 10: ORS 75 mL/kg volume
  const res10 = calculateDose({
    drug: ors,
    weightKg: 10,
    ageYears: 1,
    ageMonths: 0,
  });
  assert(res10.roundedVolumePerDoseMl === 750, `ORS 10kg gives 750 mL (got ${res10.roundedVolumePerDoseMl})`);

  // Test 11: Max single dose cap (Paracetamol for 80kg child at 15mg/kg = 1200mg -> capped at 1000mg)
  const res11 = calculateDose({
    drug: pcm,
    weightKg: 80,
    ageYears: 14,
    ageMonths: 0,
    doseSelectedMgPerKg: 15,
  });
  assert(res11.singleDoseMg === 1000, `PCM single dose capped at 1000 mg (got ${res11.singleDoseMg})`);
  assert(res11.isCappedAtMaxSingle, "PCM single dose flagged as capped");

  // Test 12: Rounding rules
  assert(roundVolumeSafely(6.4) === 6.0, "roundVolumeSafely(6.4) is 6.0");
  assert(roundVolumeSafely(6.8) === 6.5, "roundVolumeSafely(6.8) is 6.5");
  assert(roundTabletsSafely(1.7, true) === 1.5, "roundTabletsSafely(1.7, scored) is 1.5");
  assert(roundTabletsSafely(1.7, false) === 1.0, "roundTabletsSafely(1.7, unscored) is 1.0");

  console.log("=== ALL CLINICAL ENGINE TESTS PASSED! ===");
}

if (require.main === module) {
  runTests();
}
