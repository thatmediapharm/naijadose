"use client";

import React from "react";
import { X, ShieldCheck, Building2, BookCheck, AlertCircle } from "lucide-react";

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AboutModal({ isOpen, onClose }: AboutModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 bg-slate-800 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">
              Clinical Governance & About NaijaDose
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-300">
          <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700 space-y-1">
            <h4 className="font-bold text-emerald-400 text-sm flex items-center gap-1.5">
              <Building2 className="w-4 h-4" />
              ZENCARE Pharmacy and Supermarket
            </h4>
            <p className="text-slate-300">
              NaijaDose is engineered as an internal clinical decision support platform for ZENCARE
              healthcare professionals, clinic nurses, and licensed PPMV partners across Nigeria.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-slate-100 uppercase tracking-wider text-[11px] mb-1">
              Statutory Clinical Disclaimer
            </h4>
            <p className="bg-amber-950/30 text-amber-200/90 p-3 rounded-lg border border-amber-900/40 leading-relaxed">
              <strong>FOR PROFESSIONAL USE ONLY:</strong> NaijaDose supports, and never replaces, the clinical
              judgment of a licensed pharmacist or physician. Always cross-check dosage calculations against
              the physical product package label, NAFDAC-registered package leaflet, the current Nigeria
              Essential Medicines List (NEML), and national guidelines.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-slate-100 uppercase tracking-wider text-[11px] mb-1 flex items-center gap-1">
              <BookCheck className="w-3.5 h-3.5 text-emerald-400" />
              Authoritative Reference Sources
            </h4>
            <ul className="list-disc pl-4 space-y-1 text-slate-400">
              <li>Nigeria Essential Medicines List (NEML 7th Edition)</li>
              <li>British National Formulary for Children (BNFc 2024–2025)</li>
              <li>WHO Model Formulary for Children & Malaria Guidelines</li>
              <li>National Malaria Elimination Programme (NMEP) Nigeria</li>
              <li>Pharmacy Council of Nigeria (PCN) PPMV Scope Guidelines</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-100 uppercase tracking-wider text-[11px] mb-1">
              Safety Architecture & Rounding Standards
            </h4>
            <p className="leading-relaxed text-slate-400">
              To prevent inadvertent measuring errors, volumes are rounded down to practical 0.5 mL oral
              syringe increments. Unscored tablets are never divided. Doses that exceed paediatric single or
              daily ceiling thresholds are strictly blocked or capped.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-slate-100 uppercase tracking-wider text-[11px] mb-1">
              Adverse Drug Reactions (ADR)
            </h4>
            <p className="text-slate-400 leading-relaxed">
              Suspected adverse reactions should be reported immediately to the NAFDAC National
              Pharmacovigilance Centre (NPC) via the Med Safety App or Yellow Form.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-800 border-t border-slate-700 text-right">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
}
