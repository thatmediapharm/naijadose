import "dotenv/config";
import { pool, db } from "./index";
import { STARTER_DRUGS } from "../lib/starterDrugs";
import { drugs, drugFormulations, staffProfiles } from "./schema";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  const client = await pool.connect();
  try {
    // 1. Ensure ENUM types exist in PostgreSQL
    await client.query(`
      DO $$ BEGIN
        CREATE TYPE calc_method AS ENUM ('mg_per_kg', 'weight_band', 'age_band', 'volume_per_kg', 'fixed');
      EXCEPTION
        WHEN duplicate_object THEN null;
      END $$;

      DO $$ BEGIN
        CREATE TYPE dose_basis AS ENUM ('per_dose', 'per_day');
      EXCEPTION
        WHEN duplicate_object THEN null;
      END $$;

      DO $$ BEGIN
        CREATE TYPE staff_role AS ENUM ('pharmacist', 'nurse', 'ppmv', 'admin');
      EXCEPTION
        WHEN duplicate_object THEN null;
      END $$;
    `);

    // 2. Ensure tables exist
    await client.query(`
      CREATE TABLE IF NOT EXISTS staff_profiles (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        email TEXT NOT NULL UNIQUE,
        full_name TEXT NOT NULL,
        role staff_role NOT NULL DEFAULT 'pharmacist',
        facility_name TEXT NOT NULL DEFAULT 'ZENCARE Pharmacy & Supermarket',
        license_number TEXT,
        avatar_url TEXT,
        is_active BOOLEAN NOT NULL DEFAULT true,
        created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS drugs (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        generic_name TEXT NOT NULL,
        brand_names TEXT[] NOT NULL DEFAULT '{}',
        drug_class TEXT NOT NULL,
        calc_method calc_method NOT NULL,
        dose_basis dose_basis NOT NULL DEFAULT 'per_dose',
        dose_min_mg_per_kg NUMERIC(8,2),
        dose_max_mg_per_kg NUMERIC(8,2),
        doses_per_day_min INTEGER,
        doses_per_day_max INTEGER,
        frequency_text TEXT NOT NULL,
        typical_duration_days INTEGER,
        max_single_dose_mg NUMERIC(10,2),
        max_daily_dose_mg NUMERIC(10,2),
        max_daily_mg_per_kg NUMERIC(8,2),
        min_age_months NUMERIC(6,1) NOT NULL DEFAULT 0,
        min_weight_kg NUMERIC(6,2),
        max_weight_kg NUMERIC(6,2),
        band_rules JSONB,
        indications TEXT NOT NULL,
        contraindications TEXT NOT NULL,
        warnings TEXT NOT NULL,
        counselling_notes TEXT NOT NULL,
        nafdac_otc BOOLEAN NOT NULL DEFAULT false,
        ppmv_allowed BOOLEAN NOT NULL DEFAULT false,
        prescription_only BOOLEAN NOT NULL DEFAULT true,
        source_reference TEXT NOT NULL,
        last_reviewed_at TEXT NOT NULL,
        reviewed_by TEXT NOT NULL,
        is_active BOOLEAN NOT NULL DEFAULT true,
        created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
        updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
      );

      CREATE TABLE IF NOT EXISTS drug_formulations (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        drug_id UUID NOT NULL REFERENCES drugs(id) ON DELETE CASCADE,
        form TEXT NOT NULL,
        strength_mg NUMERIC(10,2) NOT NULL,
        per_volume_ml NUMERIC(8,2),
        label_text TEXT NOT NULL,
        is_scored BOOLEAN NOT NULL DEFAULT false,
        is_default BOOLEAN NOT NULL DEFAULT false
      );

      CREATE TABLE IF NOT EXISTS calculations (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        drug_id UUID REFERENCES drugs(id) ON DELETE SET NULL,
        drug_name TEXT NOT NULL,
        patient_age_months NUMERIC(6,1) NOT NULL,
        patient_weight_kg NUMERIC(6,2) NOT NULL,
        formulation_label TEXT NOT NULL,
        calculated_dose_mg NUMERIC(10,2),
        calculated_volume_ml NUMERIC(8,2),
        calculated_tablets NUMERIC(6,2),
        frequency_text TEXT NOT NULL,
        duration_days INTEGER,
        daily_total_mg NUMERIC(10,2),
        safety_status TEXT NOT NULL DEFAULT 'normal',
        safety_notes TEXT[],
        staff_email TEXT NOT NULL,
        staff_name TEXT NOT NULL,
        staff_role TEXT NOT NULL,
        notes TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
      );
    `);

    // 3. Seed staff profiles
    const defaultStaff = [
      {
        email: "ngozi@zencare.ng",
        fullName: "Pharm. Ngozi Adebayo, B.Pharm, MPSN",
        role: "pharmacist" as const,
        facilityName: "ZENCARE Pharmacy (Victoria Island, Lagos)",
        licenseNumber: "PCN/R/44912",
        avatarUrl: "👩🏾‍⚕️",
      },
      {
        email: "amina@zencare.ng",
        fullName: "Nurse Amina Bello, RN, RM",
        role: "nurse" as const,
        facilityName: "ZENCARE Outreach Clinic (Kano)",
        licenseNumber: "NMCN/N/88210",
        avatarUrl: "🩺",
      },
      {
        email: "emeka@zencare.ng",
        fullName: "Emeka Okafor (Licensed PPMV)",
        role: "ppmv" as const,
        facilityName: "Emeka Chemist & ZENCARE Partner (Enugu)",
        licenseNumber: "PCN/PPMV/0942",
        avatarUrl: "🏪",
      },
      {
        email: "admin@zencare.ng",
        fullName: "Pharm. Chinedu Eze, FPSN (Clinical Director)",
        role: "admin" as const,
        facilityName: "ZENCARE Healthcare Systems",
        licenseNumber: "PCN/F/11029",
        avatarUrl: "👨🏾‍⚕️",
      },
    ];

    for (const staff of defaultStaff) {
      await client.query(
        `
        INSERT INTO staff_profiles (email, full_name, role, facility_name, license_number, avatar_url)
        VALUES ($1, $2, $3, $4, $5, $6)
        ON CONFLICT (email) DO UPDATE
        SET full_name = EXCLUDED.full_name,
            role = EXCLUDED.role,
            facility_name = EXCLUDED.facility_name,
            license_number = EXCLUDED.license_number,
            avatar_url = EXCLUDED.avatar_url;
      `,
        [
          staff.email,
          staff.fullName,
          staff.role,
          staff.facilityName,
          staff.licenseNumber,
          staff.avatarUrl,
        ]
      );
    }

    // 4. Seed all 15 drugs and their formulations
    for (const d of STARTER_DRUGS) {
      const existing = await client.query(`SELECT id FROM drugs WHERE id = $1`, [d.id]);
      if (existing.rows.length === 0) {
        await client.query(
          `
          INSERT INTO drugs (
            id, generic_name, brand_names, drug_class, calc_method, dose_basis,
            dose_min_mg_per_kg, dose_max_mg_per_kg, doses_per_day_min, doses_per_day_max,
            frequency_text, typical_duration_days, max_single_dose_mg, max_daily_dose_mg,
            max_daily_mg_per_kg, min_age_months, min_weight_kg, max_weight_kg,
            band_rules, indications, contraindications, warnings, counselling_notes,
            nafdac_otc, ppmv_allowed, prescription_only, source_reference,
            last_reviewed_at, reviewed_by, is_active
          ) VALUES (
            $1, $2, $3, $4, $5, $6,
            $7, $8, $9, $10,
            $11, $12, $13, $14,
            $15, $16, $17, $18,
            $19, $20, $21, $22, $23,
            $24, $25, $26, $27,
            $28, $29, $30
          )
        `,
          [
            d.id,
            d.genericName,
            d.brandNames,
            d.drugClass,
            d.calcMethod,
            d.doseBasis,
            d.doseMinMgPerKg ?? null,
            d.doseMaxMgPerKg ?? null,
            d.dosesPerDayMin ?? null,
            d.dosesPerDayMax ?? null,
            d.frequencyText,
            d.typicalDurationDays ?? null,
            d.maxSingleDoseMg ?? null,
            d.maxDailyDoseMg ?? null,
            d.maxDailyMgPerKg ?? null,
            d.minAgeMonths,
            d.minWeightKg ?? null,
            d.maxWeightKg ?? null,
            d.bandRules ? JSON.stringify(d.bandRules) : null,
            d.indications,
            d.contraindications,
            d.warnings,
            d.counsellingNotes,
            d.nafdacOtc,
            d.ppmvAllowed,
            d.prescriptionOnly,
            d.sourceReference,
            d.lastReviewedAt,
            d.reviewedBy,
            d.isActive,
          ]
        );

        // Insert formulations
        for (const f of d.formulations) {
          await client.query(
            `
            INSERT INTO drug_formulations (
              id, drug_id, form, strength_mg, per_volume_ml, label_text, is_scored, is_default
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            ON CONFLICT (id) DO NOTHING;
          `,
            [
              f.id,
              f.drugId,
              f.form,
              f.strengthMg,
              f.perVolumeMl,
              f.labelText,
              f.isScored,
              f.isDefault ?? false,
            ]
          );
        }
      }
    }

    console.log("Database seeded successfully with 15 paediatric drugs and staff profiles.");
  } finally {
    client.release();
  }
}

// Allow direct execution: npx tsx src/db/seed.ts
if (require.main === module) {
  seedDatabase()
    .then(() => {
      console.log("Seed script finished.");
      process.exit(0);
    })
    .catch((err) => {
      console.error("Error during seed:", err);
      process.exit(1);
    });
}
