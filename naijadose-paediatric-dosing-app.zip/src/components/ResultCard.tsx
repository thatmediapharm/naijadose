"use client";

import React, { useState } from "react";
import { CalculationResult, Drug, StaffProfile } from "@/lib/types";
import {
  AlertTriangle,
  CheckCircle2,
  AlertOctagon,
  Copy,
  Share2,
  Printer,
  ChevronDown,
  ChevronUp,
  Info,
  Clock,
  Sparkles,
  Check,
} from "lucide-react";
import PrintLabelModal from "./PrintLabelModal";

interface ResultCardProps {
  result: CalculationResult | null;
  drug: Drug;
  weightKg: number;
  ageYears: number;
  ageMonths: number;
  staff: StaffProfile;
}

export default function ResultCard({
  result,
  drug,
  weightKg,
  ageYears,
  ageMonths,
  staff,
}: ResultCardProps) {
  const [copied, setCopied] = useState(false);
  const [showFormulaDetails, setShowFormulaDetails] = useState(false);
  const [showPrintModal, setShowPrintModal] = useState(false);

  if (!result) return null;

  const totalAgeMonths = (ageYears || 0) * 12 + (ageMonths || 0);
  const ageDisplay =
    totalAgeMonths < 12
      ? `${totalAgeMonths} month${totalAgeMonths === 1 ? "" : "s"}`
      : `${(totalAgeMonths / 12).toFixed(1).replace(".0", "")} yr${
          totalAgeMonths / 12 > 1 ? "s" : ""
        }`;

  // WhatsApp formatted string
  const generateWhatsAppMessage = () => {
    return (
      `*ZENCARE PHARMACY - PAEDIATRIC DOSE SUMMARY*\n` +
      `-----------------------------------------\n` +
      `👶 *Patient:* ${ageDisplay} | *Weight:* ${weightKg} kg\n` +
      `💊 *Medication:* ${drug.genericName}\n` +
      `🧴 *Formulation:* ${result.formulation?.labelText || "Standard"}\n\n` +
      `✅ *DOSE TO GIVE: ${result.displayDosePrimary}*\n` +
      `⏱️ *How often:* ${result.frequencyText}\n` +
      `📅 *Duration:* ${result.typicalDurationDays} days\n\n` +
      `📝 *Caregiver Instructions:*\n${result.counsellingNotes}\n\n` +
      `⚠️ *Caution:*\n${result.clinicalWarnings || "Keep strictly out of reach of children."}\n\n` +
      `Dispensed by: ${staff.fullName} (${staff.facilityName})\n` +
      `Ref: NaijaDose / ${result.sourceReference}`
    );
  };

  const handleCopy = async () => {
    const text = generateWhatsAppMessage();
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // fallback
    }
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(generateWhatsAppMessage());
    window.open(`https://api.whatsapp.com/send?text=${text}`, "_blank");
  };

  return (
    <>
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl shadow-xl overflow-hidden backdrop-blur-sm transition-all duration-300">
        {/* Top Status Header */}
        <div
          className={`px-5 py-3 border-b flex items-center justify-between gap-3 ${
            !result.isSafe
              ? "bg-rose-950/60 border-rose-800/50 text-rose-200"
              : result.softWarnings.length > 0
              ? "bg-amber-950/50 border-amber-800/50 text-amber-200"
              : "bg-emerald-950/50 border-emerald-800/50 text-emerald-200"
          }`}
        >
          <div className="flex items-center gap-2">
            {!result.isSafe ? (
              <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0 animate-bounce" />
            ) : result.softWarnings.length > 0 ? (
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            )}
            <span className="font-bold text-sm tracking-wide">
              {!result.isSafe
                ? "SAFETY HARD STOP – CALCULATION BLOCKED"
                : result.softWarnings.length > 0
                ? "CALCULATION COMPLETE (WITH CLINICAL ALERTS)"
                : "CLINICALLY VERIFIED DOSE (SAFE)"}
            </span>
          </div>

          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900/60 border border-slate-700/60 text-slate-300">
            {drug.calcMethod === "mg_per_kg"
              ? "mg/kg"
              : drug.calcMethod === "weight_band"
              ? "Weight Band"
              : drug.calcMethod === "age_band"
              ? "Age Band"
              : "Volume"}
          </span>
        </div>

        {/* Hard Stops (Red Alert Box) */}
        {!result.isSafe && (
          <div className="p-5 bg-rose-950/30 border-b border-rose-900/40 space-y-3">
            {result.hardStops.map((stop, i) => (
              <div
                key={i}
                className="bg-rose-900/40 border border-rose-600/50 rounded-xl p-4 text-rose-100"
              >
                <div className="flex items-start gap-2.5">
                  <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-sm text-rose-200">{stop.title}</h4>
                    <p className="text-xs text-rose-200/90 mt-1">{stop.message}</p>
                    {stop.actionRequired && (
                      <div className="mt-2 text-xs font-semibold text-rose-300 bg-rose-950/70 p-2 rounded-lg border border-rose-700/40">
                        <strong>Required Action:</strong> {stop.actionRequired}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Soft Warnings (Amber Alert Box) */}
        {result.isSafe && result.softWarnings.length > 0 && (
          <div className="p-4 bg-amber-950/25 border-b border-amber-900/40 space-y-2">
            {result.softWarnings.map((warning, i) => (
              <div
                key={i}
                className="bg-amber-900/30 border border-amber-600/40 rounded-xl p-3 text-amber-100"
              >
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-bold text-xs text-amber-200">{warning.title}</h5>
                    <p className="text-xs text-amber-200/80 mt-0.5">{warning.message}</p>
                    {warning.actionRequired && (
                      <p className="text-[11px] font-medium text-amber-300 mt-1">
                        ↳ <em>{warning.actionRequired}</em>
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Main Dosage Body (If Safe) */}
        {result.isSafe ? (
          <div className="p-5 sm:p-6 space-y-5">
            {/* Primary Big Dosage Number */}
            <div className="text-center py-4 px-3 bg-gradient-to-b from-slate-900/90 to-slate-950/90 rounded-2xl border border-slate-700/60 shadow-inner">
              <span className="text-xs uppercase font-extrabold tracking-wider text-slate-400">
                Dispense Single Dose
              </span>
              <div className="my-2">
                <span className="text-4xl sm:text-5xl font-black tracking-tight text-emerald-400 drop-shadow-md">
                  {result.displayDosePrimary}
                </span>
              </div>
              <p className="text-sm font-semibold text-slate-200">
                {result.displayDoseSecondary}
              </p>
              <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 text-slate-300 text-xs border border-slate-700">
                <Clock className="w-3.5 h-3.5 text-emerald-400" />
                <span>{result.frequencyText}</span>
              </div>
            </div>

            {/* Formulation & Treatment Duration Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-slate-900/60 border border-slate-800 p-3.5 rounded-xl">
                <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
                  Formulation Strength
                </span>
                <p className="text-sm font-bold text-slate-200 mt-0.5">
                  {result.formulation?.labelText || "Standard Formulation"}
                </p>
                <p className="text-[11px] text-slate-400">
                  {result.formulation?.form === "syrup" ||
                  result.formulation?.form === "suspension"
                    ? "Oral liquid (measure with syringe)"
                    : result.formulation?.form === "tablet"
                    ? result.formulation.isScored
                      ? "Scored tablet (breakable)"
                      : "Whole tablet (unscored)"
                    : "Special formulation"}
                </p>
              </div>

              <div className="bg-slate-900/60 border border-slate-800 p-3.5 rounded-xl">
                <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
                  Recommended Course
                </span>
                <p className="text-sm font-bold text-slate-200 mt-0.5">
                  {result.typicalDurationDays} Days Duration
                </p>
                <p className="text-[11px] text-slate-400">
                  {result.dosesPerDay} dose{result.dosesPerDay > 1 ? "s" : ""} per 24 hours
                </p>
              </div>
            </div>

            {/* Formula Audit & Math Dropdown */}
            <div className="border border-slate-700/60 rounded-xl overflow-hidden bg-slate-900/40">
              <button
                onClick={() => setShowFormulaDetails(!showFormulaDetails)}
                className="w-full px-4 py-2.5 flex items-center justify-between text-left text-xs font-semibold text-slate-300 hover:bg-slate-800/60 transition"
              >
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  Formula & Dosing Math Breakdown
                </span>
                {showFormulaDetails ? (
                  <ChevronUp className="w-4 h-4 text-slate-400" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                )}
              </button>

              {showFormulaDetails && (
                <div className="px-4 py-3 border-t border-slate-800 text-xs text-slate-300 space-y-2 bg-slate-950/60 font-mono">
                  <p className="text-emerald-300">{result.formulaApplied}</p>
                  {result.isCappedAtMaxSingle && (
                    <p className="text-amber-400">
                      ⚠️ Note: Single dose was capped to max limit of {drug.maxSingleDoseMg} mg.
                    </p>
                  )}
                  {result.isCappedAtMaxDaily && (
                    <p className="text-amber-400">
                      ⚠️ Note: Daily dose was capped to max limit of {drug.maxDailyDoseMg} mg/day.
                    </p>
                  )}
                  <p className="text-[11px] text-slate-400">
                    Source: {result.sourceReference}
                  </p>
                </div>
              )}
            </div>

            {/* Caregiver Counselling Box */}
            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-700/70 space-y-1.5">
              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wide flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5" />
                Caregiver Counselling Points
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {result.counsellingNotes}
              </p>
            </div>

            {/* Quick Action Buttons (Copy, WhatsApp, Print Label) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
              <button
                onClick={handleCopy}
                className="flex items-center justify-center gap-2 bg-slate-700/80 hover:bg-slate-700 text-slate-100 px-4 py-2.5 rounded-xl text-xs font-bold transition active:scale-95 border border-slate-600"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-slate-300" />
                    <span>Copy Summary</span>
                  </>
                )}
              </button>

              <button
                onClick={handleShareWhatsApp}
                className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-emerald-900/30 transition active:scale-95"
              >
                <Share2 className="w-4 h-4" />
                <span>WhatsApp Caregiver</span>
              </button>

              <button
                onClick={() => setShowPrintModal(true)}
                className="flex items-center justify-center gap-2 bg-teal-600 hover:bg-teal-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-teal-900/30 transition active:scale-95"
              >
                <Printer className="w-4 h-4" />
                <span>Print Bottle Label</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6 text-center space-y-2">
            <p className="text-sm font-semibold text-rose-300">
              Prescription or dispensing of this drug is contraindicated for the patient's inputs.
            </p>
            <p className="text-xs text-slate-400">
              Refer to hospital or consult a licensed senior paediatrician before proceeding.
            </p>
          </div>
        )}

        {/* Footer Disclaimer */}
        <div className="px-5 py-2.5 bg-slate-900/90 border-t border-slate-800 text-[10px] text-slate-400 text-center">
          {result.disclaimer}
        </div>
      </div>

      {/* Printable Label Modal */}
      {result.isSafe && (
        <PrintLabelModal
          isOpen={showPrintModal}
          onClose={() => setShowPrintModal(false)}
          drug={drug}
          result={result}
          weightKg={weightKg}
          ageYears={ageYears}
          ageMonths={ageMonths}
          staff={staff}
        />
      )}
    </>
  );
}
